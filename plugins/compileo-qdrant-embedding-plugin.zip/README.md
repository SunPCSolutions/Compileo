# Qdrant Embedding Plugin (Compileo)

Installable plugin that adds topic-agnostic vector embedding/indexing for Compileo chunks, optimized for RAG retrieval over textbook-style materials (chapters/subchapters of varied lengths).

## What this plugin adds

- Plugin API routes under `\/api\/v1\/plugins\/embeddings/*`
- Plugin CLI command group: `compileo embeddings ...`
- Plugin GUI page entry under the Compileo sidebar (via plugin page extension)
- Plugin background executor (`compileo.job.executor`) for asynchronous indexing

## Current scope (v0.2.0)

- Chunk selection and payload shaping
- Optional taxonomy metadata enrichment flag (stored in payload metadata)
- Chunk-focused taxonomy generation/cache mode using tenant `embed` table
- Legacy fallback mode using project taxonomy + chunk annotations
- Model and endpoint settings persisted via `BackendSettings`
- Job submission through core plugin-job endpoint
- Executor contract and progress callbacks

Qdrant upsert/search logic is still scaffolded while taxonomy metadata and storage integration are now implemented.

## Settings keys used

- `embedding_qdrant_url`
- `embedding_qdrant_collection`
- `embedding_ollama_url`
- `embedding_ollama_model`
- `embedding_distance`
- `embedding_batch_size`
- `embedding_include_taxonomy`
- `embedding_taxonomy_mode`
- `embedding_preprocess_policy`
- `embedding_taxonomy_generator`
- `embedding_taxonomy_processing_mode`

## Taxonomy metadata payload contract

When taxonomy is enabled and available, payload metadata includes:

```json
{
  "taxonomy": {
    "mode": "chunk",
    "provider": "gemini",
    "model": "gemini-3-flash-preview",
    "tree": [
      {
        "name": "Renal Disorders",
        "children": [
          {
            "name": "Acute Kidney Injury",
            "children": [
              { "name": "Diagnosis", "id": "11010" },
              { "name": "Treatment", "id": "11011" }
            ]
          }
        ]
      }
    ],
    "leaf_ids": ["11010", "11011"]
  }
}
```

Notes:
- `tree` is root-stripped (top file/document root category omitted).
- `mode` can be `chunk` or `legacy`.
- `leaf_ids` is optional and may be empty when IDs are unavailable.

## Install

Zip the plugin root and install from Compileo Plugins tab.
