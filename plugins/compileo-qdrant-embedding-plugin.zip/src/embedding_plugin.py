"""
Compileo Qdrant Embedding Plugin.

Provides API, CLI, GUI page extension, and background executor hooks for
chunk embedding/indexing workflows.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import click
import requests
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from src.compileo.api.core.dependencies import get_current_active_user
from src.compileo.api.models.user import User as UserSchema
from src.compileo.core.settings import BackendSettings
from src.compileo.storage.src.project.database_repositories import (
    ChunkRepository,
    DocumentRepository,
    EmbedRepository,
    ProjectRepository,
    TaxonomyRepository,
)
from src.compileo.storage.src.project.file_manager import FileManager

logger = logging.getLogger(__name__)
plugin_router = APIRouter()


def _get_plugin_manager():
    """Lazy import to avoid plugin-manager circular import during plugin load."""
    from src.compileo.features.plugin.manager import plugin_manager

    return plugin_manager


def _settings(owner_id: Optional[str]) -> BackendSettings:
    return BackendSettings(owner_id=owner_id)


def _coerce_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _coerce_bool(value: Any, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"1", "true", "yes", "on"}:
            return True
        if lowered in {"0", "false", "no", "off"}:
            return False
    return default


def _make_json_safe(value: Any) -> Any:
    """Convert nested values to JSON-serializable primitives."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _make_json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_make_json_safe(v) for v in value]
    if hasattr(value, "isoformat") and callable(getattr(value, "isoformat")):
        try:
            return value.isoformat()
        except Exception:
            pass
    return str(value)


def _fetch_ollama_models(base_url: str) -> List[str]:
    try:
        response = requests.get(f"{base_url.rstrip('/')}/api/tags", timeout=5)
        response.raise_for_status()
        data = response.json() if response.content else {}
        models = data.get("models", []) if isinstance(data, dict) else []
        names: List[str] = []
        for model in models:
            if isinstance(model, dict) and model.get("name"):
                names.append(str(model["name"]))
            elif isinstance(model, str):
                names.append(model)
        return sorted(set(names))
    except Exception as exc:
        logger.warning("Failed to fetch Ollama models from %s: %s", base_url, exc)
        return []


def _probe_qdrant_collections(qdrant_url: str, timeout_seconds: int = 5) -> Dict[str, Any]:
    """Best-effort connectivity probe for Qdrant collections API."""
    base = (qdrant_url or "").rstrip("/")
    if not base:
        return {
            "ok": False,
            "error": "empty_qdrant_url",
            "collections": [],
            "collection_count": 0,
            "status_code": None,
        }

    target = f"{base}/collections"
    try:
        response = requests.get(target, timeout=timeout_seconds)
        status_code = response.status_code
        payload = response.json() if response.content else {}

        raw_collections = []
        if isinstance(payload, dict):
            result = payload.get("result")
            if isinstance(result, dict):
                raw_collections = result.get("collections") or []

        names: List[str] = []
        if isinstance(raw_collections, list):
            for item in raw_collections:
                if isinstance(item, dict) and item.get("name"):
                    names.append(str(item.get("name")))

        return {
            "ok": 200 <= status_code < 300,
            "status_code": status_code,
            "collections": names,
            "collection_count": len(names),
            "error": None,
        }
    except Exception as exc:
        return {
            "ok": False,
            "status_code": None,
            "collections": [],
            "collection_count": 0,
            "error": str(exc),
        }


def _distance_to_qdrant(distance: str) -> str:
    normalized = str(distance or "Cosine").strip().lower()
    if normalized in {"cosine", "cos"}:
        return "Cosine"
    if normalized in {"dot", "dotproduct", "dot_product"}:
        return "Dot"
    if normalized in {"euclid", "euclidean", "l2"}:
        return "Euclid"
    return "Cosine"


def _normalize_embedding_vector(raw_vector: Any) -> Optional[List[float]]:
    if not isinstance(raw_vector, list) or not raw_vector:
        return None
    normalized: List[float] = []
    for value in raw_vector:
        try:
            normalized.append(float(value))
        except Exception:
            return None
    return normalized if normalized else None


def _extract_ollama_embeddings(response_payload: Any) -> List[List[float]]:
    if not isinstance(response_payload, dict):
        return []

    vectors: List[List[float]] = []
    embeddings = response_payload.get("embeddings")
    if isinstance(embeddings, list):
        for item in embeddings:
            normalized = _normalize_embedding_vector(item)
            if normalized:
                vectors.append(normalized)
        if vectors:
            return vectors

    embedding = response_payload.get("embedding")
    normalized_single = _normalize_embedding_vector(embedding)
    if normalized_single:
        return [normalized_single]

    return []


def _embed_texts_with_ollama(ollama_url: str, model: str, texts: List[str]) -> List[List[float]]:
    base = (ollama_url or "").rstrip("/")
    if not base:
        raise ValueError("embedding_ollama_url is empty")
    if not model:
        raise ValueError("embedding model is empty")
    if not texts:
        return []

    endpoint = f"{base}/api/embed"
    try:
        response = requests.post(
            endpoint,
            json={"model": model, "input": texts},
            timeout=120,
        )
        response.raise_for_status()
        payload = response.json() if response.content else {}
        vectors = _extract_ollama_embeddings(payload)
        if len(vectors) == len(texts):
            return vectors
        logger.warning(
            "Unexpected /api/embed batch response shape model=%s expected=%s got=%s",
            model,
            len(texts),
            len(vectors),
        )
    except Exception as exc:
        logger.warning("Ollama batch embed failed model=%s endpoint=%s error=%s", model, endpoint, exc)

    vectors: List[List[float]] = []
    for index, text in enumerate(texts):
        embedded: Optional[List[float]] = None

        try:
            response = requests.post(
                endpoint,
                json={"model": model, "input": text},
                timeout=120,
            )
            response.raise_for_status()
            payload = response.json() if response.content else {}
            extracted = _extract_ollama_embeddings(payload)
            if extracted:
                embedded = extracted[0]
        except Exception:
            embedded = None

        if embedded is None:
            legacy_endpoint = f"{base}/api/embeddings"
            response = requests.post(
                legacy_endpoint,
                json={"model": model, "prompt": text},
                timeout=120,
            )
            response.raise_for_status()
            payload = response.json() if response.content else {}
            extracted = _extract_ollama_embeddings(payload)
            if not extracted:
                raise ValueError(f"No embedding returned for text index {index}")
            embedded = extracted[0]

        vectors.append(embedded)

    if len(vectors) != len(texts):
        raise ValueError(f"Embedding count mismatch: expected {len(texts)} got {len(vectors)}")
    return vectors


def _fetch_qdrant_collection_info(qdrant_url: str, collection: str) -> Optional[Dict[str, Any]]:
    base = (qdrant_url or "").rstrip("/")
    response = requests.get(f"{base}/collections/{collection}", timeout=10)
    if response.status_code == 404:
        return None
    response.raise_for_status()
    return response.json() if response.content else {}


def _extract_qdrant_vector_config(collection_info: Dict[str, Any]) -> Dict[str, Any]:
    result = collection_info.get("result") if isinstance(collection_info, dict) else {}
    config = result.get("config") if isinstance(result, dict) else {}
    params = config.get("params") if isinstance(config, dict) else {}
    vectors = params.get("vectors") if isinstance(params, dict) else {}

    if isinstance(vectors, dict) and "size" in vectors:
        return {
            "size": vectors.get("size"),
            "distance": vectors.get("distance"),
        }

    if isinstance(vectors, dict):
        # Named vectors setup: pick first entry
        for _, candidate in vectors.items():
            if isinstance(candidate, dict) and "size" in candidate:
                return {
                    "size": candidate.get("size"),
                    "distance": candidate.get("distance"),
                }

    return {}


def _ensure_qdrant_collection(
    qdrant_url: str,
    collection: str,
    vector_size: int,
    distance: str,
) -> Dict[str, Any]:
    base = (qdrant_url or "").rstrip("/")
    qdrant_distance = _distance_to_qdrant(distance)

    existing_info = _fetch_qdrant_collection_info(base, collection)
    if existing_info is not None:
        existing_cfg = _extract_qdrant_vector_config(existing_info)
        existing_size = int(existing_cfg.get("size") or 0)
        existing_distance = str(existing_cfg.get("distance") or "")
        if existing_size and existing_size != int(vector_size):
            raise ValueError(
                f"Existing collection '{collection}' vector size mismatch: existing={existing_size} new={vector_size}"
            )
        if existing_distance and existing_distance.lower() != qdrant_distance.lower():
            raise ValueError(
                f"Existing collection '{collection}' distance mismatch: existing={existing_distance} new={qdrant_distance}"
            )
        return {
            "created": False,
            "vector_size": existing_size or int(vector_size),
            "distance": existing_distance or qdrant_distance,
        }

    create_payload = {
        "vectors": {
            "size": int(vector_size),
            "distance": qdrant_distance,
        }
    }
    response = requests.put(
        f"{base}/collections/{collection}",
        json=create_payload,
        timeout=30,
    )
    response.raise_for_status()
    return {
        "created": True,
        "vector_size": int(vector_size),
        "distance": qdrant_distance,
    }


def _upsert_qdrant_points(
    qdrant_url: str,
    collection: str,
    points: List[Dict[str, Any]],
) -> None:
    base = (qdrant_url or "").rstrip("/")
    response = requests.put(
        f"{base}/collections/{collection}/points",
        params={"wait": "true"},
        json={"points": points},
        timeout=120,
    )
    response.raise_for_status()


def _embedding_payload_to_qdrant_point(payload: Dict[str, Any], vector: List[float]) -> Dict[str, Any]:
    point_id = str(payload.get("id") or uuid.uuid4())
    metadata_raw = payload.get("metadata")
    metadata: Dict[str, Any] = metadata_raw if isinstance(metadata_raw, dict) else {}
    parent_chunk_id = str(metadata.get("parent_chunk_id") or metadata.get("chunk_id") or point_id)
    point_payload: Dict[str, Any] = {
        "chunk_id": parent_chunk_id,
        "point_id": point_id,
        "content": payload.get("text"),
    }
    point_payload.update(metadata)
    safe_payload = _make_json_safe(point_payload)
    if isinstance(safe_payload, dict):
        safe_payload = {k: v for k, v in safe_payload.items() if v is not None}
    return {
        "id": point_id,
        "vector": vector,
        "payload": safe_payload,
    }


def _normalize_metadata(raw_metadata: Any) -> Dict[str, Any]:
    if isinstance(raw_metadata, dict):
        return raw_metadata
    if isinstance(raw_metadata, str):
        try:
            parsed = json.loads(raw_metadata)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            return {}
    return {}


def _resolve_chunk_text(chunk_row: Dict[str, Any], metadata: Dict[str, Any]) -> str:
    chunk_id = str(chunk_row.get("id") or "")
    for key in ("content", "text", "main_content"):
        value = metadata.get(key)
        if isinstance(value, str) and value.strip():
            resolved = value.strip()
            logger.debug(
                "DEBUG: chunk_text_source chunk_id=%s source=metadata.%s len=%s",
                chunk_id,
                key,
                len(resolved),
            )
            return resolved

    file_path = metadata.get("file_path") or chunk_row.get("file_path")
    if isinstance(file_path, str) and file_path.strip():
        try:
            abs_path = FileManager.get_storage_base_path() / file_path.strip()
            if abs_path.exists() and abs_path.is_file():
                full_text = abs_path.read_text(encoding="utf-8", errors="ignore").strip()
                if full_text:
                    logger.debug(
                        "DEBUG: chunk_text_source chunk_id=%s source=file_path len=%s file_path=%s",
                        chunk_id,
                        len(full_text),
                        file_path,
                    )
                    return full_text
        except Exception as exc:
            logger.debug(
                "DEBUG: chunk_text_source chunk_id=%s source=file_path_failed file_path=%s error=%s",
                chunk_id,
                file_path,
                exc,
            )

    preview = chunk_row.get("content_preview")
    resolved_preview = str(preview).strip() if preview else ""
    logger.debug(
        "DEBUG: chunk_text_source chunk_id=%s source=content_preview len=%s file_path=%s",
        chunk_id,
        len(resolved_preview),
        file_path,
    )
    return resolved_preview


def _taxonomy_root(taxonomy_data: Dict[str, Any]) -> Dict[str, Any]:
    structure = taxonomy_data.get("taxonomy_structure")
    if not isinstance(structure, dict):
        return {}
    if isinstance(structure.get("taxonomy"), dict):
        return structure["taxonomy"]
    if "children" in structure:
        return structure
    return {}


def _taxonomy_root_name(taxonomy_data: Dict[str, Any]) -> str:
    root = _taxonomy_root(taxonomy_data)
    if not isinstance(root, dict):
        return ""
    return str(root.get("name") or "").strip()


def _collect_taxonomy_entries(
    node: Dict[str, Any],
    path_names: Optional[List[str]] = None,
    path_ids: Optional[List[str]] = None,
    entries: Optional[List[Dict[str, Any]]] = None,
    is_root: bool = True,
) -> List[Dict[str, Any]]:
    path_names = list(path_names or [])
    path_ids = list(path_ids or [])
    entries = entries if entries is not None else []

    name = str(node.get("name") or "").strip()
    node_id = str(node.get("id") or "").strip()
    description = str(node.get("description") or "").strip()
    confidence = node.get("confidence_threshold")

    if name:
        path_names = path_names + [name]
    if node_id:
        path_ids = path_ids + [node_id]

    children = node.get("children") or []
    if not isinstance(children, list):
        children = []

    if not is_root and name:
        entries.append(
            {
                "name": name,
                "id": node_id or None,
                "description": description,
                "confidence": confidence,
                "path_names": path_names,
                "path_ids": path_ids,
                "is_leaf": len(children) == 0,
            }
        )

    for child in children:
        if isinstance(child, dict):
            _collect_taxonomy_entries(
                child,
                path_names=path_names,
                path_ids=path_ids,
                entries=entries,
                is_root=False,
            )
    return entries


def _taxonomy_terms(entry: Dict[str, Any]) -> List[str]:
    name = str(entry.get("name") or "")
    description = str(entry.get("description") or "")
    path_names = [str(p) for p in entry.get("path_names") or []]

    raw_terms = re.findall(r"[A-Za-z][A-Za-z0-9\-]{3,}", " ".join([name, description] + path_names).lower())
    stop_words = {
        "this", "that", "with", "from", "into", "about", "when", "where", "what",
        "which", "their", "there", "these", "those", "have", "will", "would", "should",
        "could", "general", "medical", "knowledge", "including", "related",
    }
    return [t for t in raw_terms if t not in stop_words]


def _branch_key_for_entry(entry: Dict[str, Any]) -> str:
    path_names = [str(p).strip() for p in (entry.get("path_names") or []) if str(p).strip()]
    if len(path_names) >= 2:
        return path_names[1].lower()
    if path_names:
        return path_names[0].lower()
    return "unknown"


def _is_generic_taxonomy_label(name: str) -> bool:
    generic_tokens = {
        "overview", "introduction", "summary", "description", "basics", "background",
        "epidemiology", "etiology", "pathophysiology", "diagnosis", "treatment",
        "management", "complications", "outcomes", "risk", "factors", "associated",
        "conditions", "approaches", "methods", "techniques", "general", "concepts",
    }
    tokens = re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}", (name or "").lower())
    if not tokens:
        return True
    generic_hits = sum(1 for t in tokens if t in generic_tokens)
    return generic_hits >= max(1, len(tokens) - 1)


def _derive_taxonomy_context(text: str, taxonomy_data: Dict[str, Any]) -> Dict[str, Any]:
    taxonomy_id = taxonomy_data.get("taxonomy_id")
    taxonomy_name = taxonomy_data.get("taxonomy_name")
    taxonomy_name_lower = str(taxonomy_name or "").strip().lower()
    taxonomy_root_lower = _taxonomy_root_name(taxonomy_data).lower()
    root = _taxonomy_root(taxonomy_data)
    if not root:
        return {}

    entries = _collect_taxonomy_entries(root)
    if not entries:
        return {}

    lowered = (text or "").lower()
    scored: List[Dict[str, Any]] = []
    branch_stats: Dict[str, Dict[str, float]] = {}
    for entry in entries:
        score = 0
        name = str(entry.get("name") or "").lower()
        is_generic_label = _is_generic_taxonomy_label(str(entry.get("name") or ""))
        exact_name_hit = bool(name and name in lowered)
        exact_non_generic_hit = bool(exact_name_hit and not is_generic_label)
        if exact_name_hit:
            # Generic labels are down-weighted unless supported by branch anchors.
            score += 2 if is_generic_label else 5

        for term in _taxonomy_terms(entry)[:30]:
            if term in lowered:
                score += 1

        if score > 0:
            branch_key = _branch_key_for_entry(entry)
            scored.append(
                {
                    "entry": entry,
                    "score": score,
                    "exact_name_hit": exact_name_hit,
                    "exact_non_generic_hit": exact_non_generic_hit,
                    "is_generic_label": is_generic_label,
                    "branch_key": branch_key,
                }
            )
            stats = branch_stats.setdefault(
                branch_key,
                {"score": 0.0, "exact_hits": 0.0, "exact_non_generic_hits": 0.0, "top_score": 0.0},
            )
            stats["score"] += float(score)
            if exact_name_hit:
                stats["exact_hits"] += 1.0
            if exact_non_generic_hit:
                stats["exact_non_generic_hits"] += 1.0
            stats["top_score"] = max(float(stats["top_score"]), float(score))

    if not scored:
        return {}

    exact_branches = {k for k, v in branch_stats.items() if v.get("exact_non_generic_hits", 0) > 0}
    if exact_branches:
        allowed_branches = exact_branches
    else:
        primary_branch = max(
            branch_stats.items(),
            key=lambda item: (item[1].get("top_score", 0), item[1].get("score", 0)),
        )[0]
        allowed_branches = {primary_branch}

    constrained = [item for item in scored if item.get("branch_key") in allowed_branches]
    if not constrained:
        constrained = scored

    constrained.sort(
        key=lambda x: (
            1 if x.get("exact_non_generic_hit") else 0,
            1 if x.get("exact_name_hit") else 0,
            x["score"],
            len(x["entry"].get("path_names") or []),
            1 if x["entry"].get("is_leaf") else 0,
        ),
        reverse=True,
    )

    selected: List[Dict[str, Any]] = constrained[:4]

    # Optional expansion: if we have a strong non-generic primary node (topic anchor),
    # include its direct children so category families like diagnosis/treatment are present.
    primary_item = next(
        (
            item
            for item in constrained
            if item.get("exact_non_generic_hit")
            and not bool(item.get("entry", {}).get("is_leaf"))
            and len(item.get("entry", {}).get("path_names") or []) >= 2
        ),
        None,
    )
    if primary_item:
        anchor_path = list(primary_item.get("entry", {}).get("path_names") or [])
        existing_paths = {
            tuple(item.get("entry", {}).get("path_names") or [])
            for item in selected
        }
        for entry in entries:
            path = list(entry.get("path_names") or [])
            if len(path) != len(anchor_path) + 1:
                continue
            if path[: len(anchor_path)] != anchor_path:
                continue
            path_key = tuple(path)
            if path_key in existing_paths:
                continue
            selected.append(
                {
                    "entry": entry,
                    "score": 0,
                    "exact_name_hit": False,
                    "exact_non_generic_hit": False,
                    "is_generic_label": _is_generic_taxonomy_label(str(entry.get("name") or "")),
                    "branch_key": _branch_key_for_entry(entry),
                }
            )
            existing_paths.add(path_key)

    matched_leaf_ids: List[str] = []
    matched_leaf_names: List[str] = []
    matched_paths: List[str] = []
    parent_tags: List[str] = []
    confidences: List[float] = []

    for item in selected:
        entry = item["entry"]
        entry_id = entry.get("id")
        if entry_id:
            matched_leaf_ids.append(str(entry_id))
        matched_leaf_names.append(str(entry.get("name")))

        path_names = [str(p).strip() for p in (entry.get("path_names") or []) if str(p).strip()]
        if taxonomy_root_lower and path_names and path_names[0].lower() == taxonomy_root_lower:
            path_names = path_names[1:]
        elif taxonomy_name_lower and path_names and path_names[0].lower() == taxonomy_name_lower:
            path_names = path_names[1:]
        if path_names:
            matched_paths.append(" > ".join(path_names))
            if len(path_names) > 1:
                parent_tags.extend(path_names[:-1])

        confidence = entry.get("confidence")
        if isinstance(confidence, (int, float)):
            confidences.append(float(confidence))

    # De-duplicate while preserving order.
    matched_leaf_ids = list(dict.fromkeys(matched_leaf_ids))
    matched_leaf_names = list(dict.fromkeys(matched_leaf_names))
    matched_paths = list(dict.fromkeys(matched_paths))
    parent_tags = list(dict.fromkeys(parent_tags))

    return {
        "taxonomy_version_id": taxonomy_id,
        "taxonomy_name": taxonomy_name,
        "matched_leaf_ids": matched_leaf_ids,
        "matched_leaf_names": matched_leaf_names,
        "matched_paths": matched_paths,
        "parent_tags": parent_tags,
        "taxonomy_confidence": round(sum(confidences) / len(confidences), 4) if confidences else None,
    }


def _normalize_taxonomy_structure(raw_structure: Any) -> Dict[str, Any]:
    if isinstance(raw_structure, dict):
        return raw_structure
    if isinstance(raw_structure, str):
        try:
            parsed = json.loads(raw_structure)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            return {}
    return {}


def _json_loads_safe(value: Any, default: Any) -> Any:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return default
    if value is None:
        return default
    return value


def _normalize_taxonomy_tree_node(node: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(node, dict):
        return {}

    name = str(node.get("name") or "").strip()
    out: Dict[str, Any] = {}
    if name:
        out["name"] = name

    children = node.get("children") or []
    normalized_children: List[Dict[str, Any]] = []
    if isinstance(children, list):
        for child in children:
            if isinstance(child, dict):
                normalized = _normalize_taxonomy_tree_node(child)
                if normalized:
                    normalized_children.append(normalized)

    if normalized_children:
        out["children"] = normalized_children

    return out


def _taxonomy_tree_without_root(taxonomy_root: Dict[str, Any]) -> List[Dict[str, Any]]:
    normalized_root = _normalize_taxonomy_tree_node(taxonomy_root)
    if not normalized_root:
        return []
    children = normalized_root.get("children")
    if isinstance(children, list) and children:
        return children
    return [normalized_root]


def _collect_leaf_ids_from_tree(tree_nodes: List[Dict[str, Any]]) -> List[str]:
    leaf_ids: List[str] = []

    def _walk(node: Dict[str, Any]) -> None:
        children = node.get("children")
        if isinstance(children, list) and children:
            for child in children:
                if isinstance(child, dict):
                    _walk(child)
            return
        node_id = node.get("id")
        if node_id:
            leaf_ids.append(str(node_id))

    for root in tree_nodes:
        if isinstance(root, dict):
            _walk(root)

    return list(dict.fromkeys(leaf_ids))


def _extract_main_topic_from_chunk_text(text: str) -> Optional[str]:
    """Extract chunk main topic from explicit markdown headings only (H1 then H2)."""
    if not text:
        return None

    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return None

    for line in lines[:40]:
        if line.startswith("# "):
            topic = line[2:].strip()
            if topic:
                return topic

    for line in lines[:40]:
        if line.startswith("## "):
            topic = line[3:].strip()
            if topic:
                return topic

    return None


def _extract_fallback_topic_from_chunk_text(text: str) -> Optional[str]:
    """Last-resort topic fallback when heading + AI inference are unavailable."""
    if not text:
        return None
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return None
    candidate = lines[0]
    return candidate[:120].strip() if len(candidate) > 120 else candidate


def _is_generic_main_topic(topic: str) -> bool:
    """Detect overly broad inferred topics that are weak anchors."""
    normalized = (topic or "").strip().lower()
    if not normalized:
        return True

    broad_phrases = {
        "general", "overview", "introduction", "summary", "medicine", "health",
        "medical", "medical specialties", "clinical concepts", "clinical practice",
        "healthcare", "disease", "conditions", "diagnosis", "treatment",
    }
    if normalized in broad_phrases:
        return True

    tokens = re.findall(r"[A-Za-z][A-Za-z0-9\-]{2,}", normalized)
    if not tokens:
        return True

    generic_tokens = {
        "general", "overview", "introduction", "summary", "medical", "medicine",
        "health", "healthcare", "clinical", "concepts", "specialties", "disease",
        "conditions", "diagnosis", "treatment", "management", "approach", "approaches",
    }
    generic_hits = sum(1 for t in tokens if t in generic_tokens)
    return generic_hits >= max(1, len(tokens) - 1)


def _select_specific_main_topic_from_taxonomy_root(taxonomy_root: Dict[str, Any]) -> Optional[str]:
    """Pick first non-generic topic from root children, then deeper descendants."""
    if not isinstance(taxonomy_root, dict):
        return None

    level1 = _children_nodes(taxonomy_root)
    level2: List[Dict[str, Any]] = []
    level3: List[Dict[str, Any]] = []
    for node in level1:
        level2.extend(_children_nodes(node))
    for node in level2:
        level3.extend(_children_nodes(node))

    for level in (level1, level2, level3):
        for node in level:
            name = str(node.get("name") or "").strip()
            if name and not _is_generic_main_topic(name):
                return name

    if level1:
        fallback = str(level1[0].get("name") or "").strip()
        return fallback or None

    root_name = str(taxonomy_root.get("name") or "").strip()
    return root_name or None


def _infer_main_topic_with_generator(generator: Any, text: str, processing_mode: str) -> Optional[str]:
    """Infer chunk main topic from taxonomy generator output when headings are absent."""
    try:
        result = generator.generate_taxonomy(
            chunks=[text],
            domain="general",
            depth=2,
            batch_size=1,
            specificity_level=1,
            processing_mode=processing_mode,
        )
        taxonomy_root = result.get("taxonomy") if isinstance(result, dict) else {}
        if not isinstance(taxonomy_root, dict):
            return None

        selected = _select_specific_main_topic_from_taxonomy_root(taxonomy_root)
        return selected or None
    except Exception as exc:
        logger.debug("DEBUG: ai_main_topic_inference_failed error=%s", exc)
        return None


def _anchor_taxonomy_tree_with_main_topic(
    tree_nodes: List[Dict[str, Any]],
    main_topic: Optional[str],
) -> List[Dict[str, Any]]:
    """Wrap semantic tree under chunk main-topic top category for embedding-specific retrieval."""
    topic = (main_topic or "").strip()
    if not topic:
        return tree_nodes

    if len(tree_nodes) == 1 and isinstance(tree_nodes[0], dict):
        existing_name = str(tree_nodes[0].get("name") or "").strip().casefold()
        if existing_name == topic.casefold():
            return tree_nodes

    return [{"name": topic, "children": tree_nodes}]


def _children_nodes(node: Dict[str, Any]) -> List[Dict[str, Any]]:
    children = node.get("children")
    if not isinstance(children, list):
        return []
    return [child for child in children if isinstance(child, dict)]


def _build_embedding_guided_chunk_text(
    text: str,
    main_topic: Optional[str],
    anchor_main_topic: bool,
) -> str:
    """Plugin-only prompt shaping for taxonomy generation without touching core taxonomy modules."""
    if not anchor_main_topic or not main_topic:
        return text

    prefix = (
        "EMBEDDING TAXONOMY INSTRUCTION (plugin-specific):\n"
        f"- The main topic of this chunk is: {main_topic}\n"
        "- Use this main topic as the primary top category.\n"
        "- Place supporting concepts as subcategories beneath it when relevant."
    )
    return f"{prefix}\n\n{text}"


def _resolve_main_topic_for_chunk(
    text: str,
    generator: Any,
    processing_mode: str,
    anchor_main_topic: bool,
) -> Optional[str]:
    if not anchor_main_topic:
        return None

    topic = _extract_main_topic_from_chunk_text(text)
    if topic:
        return topic

    inferred = _infer_main_topic_with_generator(generator, text, processing_mode)
    if inferred:
        return inferred

    return _extract_fallback_topic_from_chunk_text(text)


def _merge_semantic_tree_nodes(
    existing_nodes: List[Dict[str, Any]],
    incoming_nodes: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Merge semantic taxonomy trees deterministically by node name."""

    def _merge_lists(current: List[Dict[str, Any]], new_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        by_name: Dict[str, Dict[str, Any]] = {}

        for node in current or []:
            if not isinstance(node, dict):
                continue
            name = str(node.get("name") or "").strip()
            if not name:
                continue
            by_name[name.casefold()] = {"name": name, "children": list(node.get("children") or [])}

        for node in new_items or []:
            if not isinstance(node, dict):
                continue
            name = str(node.get("name") or "").strip()
            if not name:
                continue
            key = name.casefold()
            existing_node = by_name.get(key)
            raw_children = node.get("children")
            new_children: List[Dict[str, Any]] = raw_children if isinstance(raw_children, list) else []
            if existing_node is None:
                by_name[key] = {"name": name, "children": []}
                existing_node = by_name[key]
            existing_children_raw = existing_node.get("children")
            existing_children: List[Dict[str, Any]] = existing_children_raw if isinstance(existing_children_raw, list) else []
            existing_node["children"] = _merge_lists(existing_children, new_children)

        merged_nodes: List[Dict[str, Any]] = []
        for key in sorted(by_name.keys()):
            node = by_name[key]
            out = {"name": node.get("name")}
            children = node.get("children") or []
            if children:
                out["children"] = children
            merged_nodes.append(out)
        return merged_nodes

    return _merge_lists(existing_nodes, incoming_nodes)


def _assign_hierarchical_ids_for_taxonomy(root: Dict[str, Any], project_id: str) -> Dict[str, Any]:
    from src.compileo.features.taxonomy.response_parser import TaxonomyResponseParser

    numeric_project = 1
    try:
        numeric_project = int(str(project_id)[:4], 16) % 97 + 1
    except Exception:
        numeric_project = 1

    return TaxonomyResponseParser._add_hierarchical_ids(root, project_id=numeric_project, taxonomy_index=9)


def _upsert_embedding_project_taxonomy(owner_id: str, project_id: str) -> Optional[str]:
    """Materialize chunk-mode semantic taxonomy into taxonomies table for UI persistence."""
    chunk_repo = ChunkRepository(owner_id)
    taxonomy_repo = TaxonomyRepository(owner_id)
    project_repo = ProjectRepository(owner_id)

    project = project_repo.get_project_by_id(project_id)
    if not project:
        return None

    with chunk_repo.cursor() as cursor:
        cursor.execute(
            """
            SELECT e.taxonomy_tree
            FROM embed e
            JOIN chunks c ON c.id = e.chunk_id
            JOIN documents d ON d.id = c.document_id
            WHERE e.owner_id = ? AND d.project_id = ?
            ORDER BY c.chunk_index ASC
            """,
            (owner_id, project_id),
        )
        rows = cursor.fetchall() or []

    merged_tree: List[Dict[str, Any]] = []
    for row in rows:
        raw_tree = row[0] if not isinstance(row, dict) else row.get("taxonomy_tree")
        tree = _json_loads_safe(raw_tree, [])
        if isinstance(tree, list):
            merged_tree = _merge_semantic_tree_nodes(merged_tree, tree)

    if not merged_tree:
        return None

    taxonomy_root = {
        "name": f"Embedding Taxonomy - {project.get('name') or project_id}",
        "description": "Project-level taxonomy materialized from chunk-mode embedding semantic trees.",
        "children": merged_tree,
    }

    taxonomy_with_ids = _assign_hierarchical_ids_for_taxonomy(taxonomy_root, project_id)

    structure = {
        "taxonomy": taxonomy_with_ids,
        "generation_metadata": {
            "type": "embedding_plugin_chunk_mode",
            "generator": "embedding_plugin",
            "timestamp": datetime.utcnow().isoformat() + "Z",
        },
        "analytics": {
            "depth_analysis": {
                "total_categories": len(merged_tree),
            }
        },
    }

    existing = taxonomy_repo.get_taxonomies_by_project(project_id)
    target_name = "Embedding Taxonomy (chunk mode)"
    existing_record = next((t for t in existing if str(t.get("name") or "") == target_name), None)

    if existing_record:
        with taxonomy_repo.cursor() as cursor:
            cursor.execute(
                "UPDATE taxonomies SET structure = ?, updated_at = ? WHERE id = ? AND owner_id = ?",
                (json.dumps(structure), datetime.utcnow(), existing_record.get("id"), owner_id),
            )
        return str(existing_record.get("id"))

    taxonomy_id = str(uuid.uuid4())
    taxonomy_repo.create_taxonomy(
        {
            "id": taxonomy_id,
            "owner_id": owner_id,
            "project_id": project_id,
            "name": target_name,
            "structure": structure,
            "file_path": None,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }
    )
    return taxonomy_id


def _chunk_text_hash(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


def _coerce_taxonomy_chunk_batch_size(value: Any, default: int = 10) -> int:
    size = _coerce_int(value, default)
    return max(1, min(256, size))


def _iter_chunk_batches(items: List[Dict[str, Any]], batch_size: int) -> List[List[Dict[str, Any]]]:
    normalized_batch_size = _coerce_taxonomy_chunk_batch_size(batch_size, 10)
    return [items[i : i + normalized_batch_size] for i in range(0, len(items), normalized_batch_size)]


def _coerce_segment_token_size(value: Any, default: int = 512) -> int:
    size = _coerce_int(value, default)
    return max(64, min(4096, size))


def _default_segment_overlap_tokens(segment_token_size: int) -> int:
    size = _coerce_segment_token_size(segment_token_size)
    overlap = int(round(size * 0.16))
    overlap = max(40, min(120, overlap))
    if overlap >= size:
        overlap = max(0, size - 1)
    return overlap


def _coerce_segment_overlap_tokens(value: Any, segment_token_size: int, default: int = 80) -> int:
    size = _coerce_segment_token_size(segment_token_size)
    overlap = _coerce_int(value, default)
    overlap = max(0, min(4096, overlap))
    if overlap >= size:
        overlap = max(0, size - 1)
    return overlap


def _estimate_token_count(text: str) -> int:
    normalized_text = str(text or "").strip()
    if not normalized_text:
        return 0

    try:
        import tiktoken

        encoding = tiktoken.get_encoding("cl100k_base")
        return len(encoding.encode(normalized_text))
    except Exception:
        return len(normalized_text.split())


def _split_text_into_token_segments(
    text: str,
    segment_token_size: int,
    overlap_tokens: int,
) -> List[Dict[str, Any]]:
    normalized_text = str(text or "").strip()
    if not normalized_text:
        return []

    max_tokens = _coerce_segment_token_size(segment_token_size)
    overlap = max(0, min(int(overlap_tokens), max_tokens - 1))
    step = max(1, max_tokens - overlap)

    try:
        import tiktoken

        encoding = tiktoken.get_encoding("cl100k_base")
        token_ids = encoding.encode(normalized_text)
        total_tokens = len(token_ids)

        if total_tokens <= max_tokens:
            return [{"text": normalized_text, "token_start": 0, "token_end": total_tokens}]

        segments: List[Dict[str, Any]] = []
        start = 0
        while start < total_tokens:
            end = min(start + max_tokens, total_tokens)
            segment_text = encoding.decode(token_ids[start:end]).strip()
            if segment_text:
                segments.append(
                    {
                        "text": segment_text,
                        "token_start": start,
                        "token_end": end,
                    }
                )
            if end >= total_tokens:
                break
            start += step

        return segments
    except Exception:
        words = normalized_text.split()
        total_tokens = len(words)
        if total_tokens <= max_tokens:
            return [{"text": normalized_text, "token_start": 0, "token_end": total_tokens}]

        segments: List[Dict[str, Any]] = []
        start = 0
        while start < total_tokens:
            end = min(start + max_tokens, total_tokens)
            segment_text = " ".join(words[start:end]).strip()
            if segment_text:
                segments.append(
                    {
                        "text": segment_text,
                        "token_start": start,
                        "token_end": end,
                    }
                )
            if end >= total_tokens:
                break
            start += step

        return segments


def _expand_payloads_with_micro_segments(
    payloads: List[Dict[str, Any]],
    segment_token_size: int,
    segment_overlap_tokens: Optional[int] = None,
    skip_segmentation: bool = False,
) -> Tuple[List[Dict[str, Any]], int, int, int]:
    normalized_size = _coerce_segment_token_size(segment_token_size)
    overlap_tokens = _coerce_segment_overlap_tokens(
        segment_overlap_tokens,
        normalized_size,
        _default_segment_overlap_tokens(normalized_size),
    )
    skip_segmentation_effective = _coerce_bool(skip_segmentation, False)

    expanded_payloads: List[Dict[str, Any]] = []
    segmented_parent_count = 0

    for payload in payloads:
        parent_chunk_id = str(payload.get("id") or uuid.uuid4())
        metadata_raw = payload.get("metadata")
        base_metadata: Dict[str, Any] = dict(metadata_raw) if isinstance(metadata_raw, dict) else {}
        base_metadata["parent_chunk_id"] = parent_chunk_id
        payload_text = str(payload.get("text") or "")

        if skip_segmentation_effective:
            if not payload_text.strip():
                continue
            token_count = _estimate_token_count(payload_text)
            passthrough_metadata = dict(base_metadata)
            passthrough_metadata.update(
                {
                    "segment_point_id": parent_chunk_id,
                    "segment_index": 0,
                    "segment_count": 1,
                    "token_start": 0,
                    "token_end": token_count,
                    "segment_token_count": token_count,
                }
            )
            expanded_payloads.append(
                {
                    "id": parent_chunk_id,
                    "text": payload_text,
                    "metadata": passthrough_metadata,
                }
            )
            continue

        segments = _split_text_into_token_segments(
            payload_text,
            segment_token_size=normalized_size,
            overlap_tokens=overlap_tokens,
        )
        if not segments:
            continue

        segment_count = len(segments)
        if segment_count > 1:
            segmented_parent_count += 1

        for idx, segment in enumerate(segments):
            segment_point_id = parent_chunk_id if segment_count == 1 else f"{parent_chunk_id}#seg_{idx}"
            point_id = segment_point_id
            if segment_count > 1:
                try:
                    point_id = str(uuid.uuid5(uuid.UUID(parent_chunk_id), f"seg:{idx}"))
                except Exception:
                    point_id = str(uuid.uuid5(uuid.NAMESPACE_URL, segment_point_id))
            segment_metadata = dict(base_metadata)
            segment_metadata.update(
                {
                    "segment_point_id": segment_point_id,
                    "segment_index": idx,
                    "segment_count": segment_count,
                    "token_start": int(segment.get("token_start") or 0),
                    "token_end": int(segment.get("token_end") or 0),
                    "segment_token_count": max(
                        0,
                        int(segment.get("token_end") or 0) - int(segment.get("token_start") or 0),
                    ),
                }
            )
            expanded_payloads.append(
                {
                    "id": point_id,
                    "text": str(segment.get("text") or ""),
                    "metadata": segment_metadata,
                }
            )

    return expanded_payloads, normalized_size, overlap_tokens, segmented_parent_count


def _resolve_taxonomy_generator(owner_id: str, generator_name: Optional[str]):
    settings = BackendSettings(owner_id=owner_id)
    # If no specific generator provided, use the taxonomy provider from settings
    # (same as non-embedding taxonomy jobs)
    provider = generator_name.strip().lower() if generator_name else None
    if not provider:
        provider = settings.get_taxonomy_provider()

    if provider == "grok":
        api_key = settings.get_setting("grok_api_key")
        if not api_key:
            raise ValueError("grok_api_key is required for chunk taxonomy generation")
        model_name = settings.get_taxonomy_grok_model()
        from src.compileo.features.taxonomy.grok_generator import GrokTaxonomyGenerator

        return provider, model_name, GrokTaxonomyGenerator(str(api_key), model=model_name)

    if provider == "gemini":
        api_key = settings.get_setting("gemini_api_key")
        if not api_key:
            raise ValueError("gemini_api_key is required for chunk taxonomy generation")
        model_name = settings.get_taxonomy_gemini_model()
        from src.compileo.features.taxonomy.gemini_generator import GeminiTaxonomyGenerator

        return provider, model_name, GeminiTaxonomyGenerator(str(api_key), model=model_name)

    if provider == "openai":
        api_key = settings.get_setting("openai_api_key")
        if not api_key:
            raise ValueError("openai_api_key is required for chunk taxonomy generation")
        model_name = settings.get_taxonomy_openai_model()
        from src.compileo.features.taxonomy.openai_generator import OpenAITaxonomyGenerator

        return provider, model_name, OpenAITaxonomyGenerator(str(api_key), model=model_name)

    if provider == "ollama":
        model_name = settings.get_taxonomy_ollama_model()
        from src.compileo.features.taxonomy.ollama_generator import OllamaTaxonomyGenerator

        return provider, model_name, OllamaTaxonomyGenerator(model=model_name)

    raise ValueError(f"Unsupported taxonomy generator: {generator_name}")


def _generate_chunk_taxonomy_tree(
    generator: Any,
    text: str,
    processing_mode: str,
    anchor_main_topic: bool,
) -> Dict[str, Any]:
    main_topic = _resolve_main_topic_for_chunk(text, generator, processing_mode, anchor_main_topic)
    guided_text = _build_embedding_guided_chunk_text(text, main_topic, bool(main_topic) and anchor_main_topic)
    result = generator.generate_taxonomy(
        chunks=[guided_text],
        domain="general",
        depth=3,
        batch_size=1,
        specificity_level=1,
        processing_mode=processing_mode,
    )
    taxonomy_root = result.get("taxonomy") if isinstance(result, dict) else {}
    if not isinstance(taxonomy_root, dict):
        taxonomy_root = {}

    root_children = _children_nodes(taxonomy_root)
    raw_children = root_children if root_children else [taxonomy_root]
    leaf_ids = _collect_leaf_ids_from_tree(raw_children)

    tree = _taxonomy_tree_without_root(taxonomy_root)
    if anchor_main_topic:
        tree = _anchor_taxonomy_tree_with_main_topic(tree, main_topic)

    if not leaf_ids:
        leaf_ids = _collect_leaf_ids_from_tree(tree)

    return {
        "tree": tree,
        "leaf_ids": leaf_ids,
    }


def _ensure_embed_taxonomy_records(
    owner_id: str,
    payload: "EmbedIndexRequest",
    chunks: List[Dict[str, Any]],
) -> Dict[str, Any]:
    if not payload.project_id:
        return {"updated": False, "reason": "missing_project_id", "mode": "chunk"}
    if not chunks:
        return {"updated": False, "reason": "no_chunks", "mode": "chunk"}

    cfg = EmbeddingPluginConfig.load(owner_id)
    generator_name = (payload.taxonomy_generator or cfg.taxonomy_generator or "gemini").strip().lower()
    processing_mode = payload.taxonomy_processing_mode or cfg.taxonomy_processing_mode or "fast"
    anchor_main_topic = cfg.taxonomy_anchor_main_topic if payload.taxonomy_anchor_main_topic is None else bool(payload.taxonomy_anchor_main_topic)
    effective_chunk_batch_size = _coerce_taxonomy_chunk_batch_size(
        payload.taxonomy_chunk_batch_size if payload.taxonomy_chunk_batch_size is not None else cfg.taxonomy_chunk_batch_size,
        cfg.taxonomy_chunk_batch_size,
    )
    expected_generation_mode = "chunk_anchor" if anchor_main_topic else "chunk"
    provider, model_name, generator = _resolve_taxonomy_generator(owner_id, generator_name)

    repo = EmbedRepository(owner_id)
    chunk_ids = [str(c.get("id")) for c in chunks if c.get("id")]
    existing_map = repo.get_embed_by_chunk_ids(chunk_ids)

    generated = 0
    updated = 0
    skipped = 0
    failed: List[Dict[str, str]] = []

    pending_rows: List[Dict[str, Any]] = []

    for row in chunks:
        chunk_id = str(row.get("id") or "").strip()
        if not chunk_id:
            continue

        metadata = _normalize_metadata(row.get("metadata"))
        text = _resolve_chunk_text(row, metadata)
        if not text:
            skipped += 1
            continue

        chunk_hash = _chunk_text_hash(text)
        existing = existing_map.get(chunk_id)
        if existing:
            existing_hash = str(existing.get("chunk_hash") or "")
            existing_provider = str(existing.get("taxonomy_provider") or "")
            existing_model = str(existing.get("taxonomy_model") or "")
            existing_generation_mode = str(existing.get("generation_mode") or "")
            if (
                existing_hash == chunk_hash
                and existing_provider == provider
                and existing_model == str(model_name or "")
                and existing_generation_mode == expected_generation_mode
            ):
                skipped += 1
                continue

        pending_rows.append(
            {
                "row": row,
                "chunk_id": chunk_id,
                "chunk_hash": chunk_hash,
                "text": text,
                "existing": bool(existing),
            }
        )

    pending_batches = _iter_chunk_batches(pending_rows, effective_chunk_batch_size)
    total_batches = len(pending_batches)

    def _generate_for_item(item: Dict[str, Any]) -> Dict[str, Any]:
        chunk_generator = generator
        if effective_chunk_batch_size > 1:
            _, _, chunk_generator = _resolve_taxonomy_generator(owner_id, generator_name)
        taxonomy_payload = _generate_chunk_taxonomy_tree(
            chunk_generator,
            item["text"],
            processing_mode,
            anchor_main_topic=anchor_main_topic,
        )
        return {
            "chunk_id": item["chunk_id"],
            "taxonomy_payload": taxonomy_payload,
            "row": item["row"],
            "chunk_hash": item["chunk_hash"],
            "existing": item["existing"],
        }

    for batch_index, batch_items in enumerate(pending_batches, start=1):
        logger.debug(
            "DEBUG: embed_chunk_taxonomy_batch_start batch=%s/%s size=%s batch_size=%s",
            batch_index,
            total_batches,
            len(batch_items),
            effective_chunk_batch_size,
        )

        batch_results: List[Dict[str, Any]] = []
        if len(batch_items) == 1:
            item = batch_items[0]
            try:
                batch_results.append(_generate_for_item(item))
            except Exception as exc:
                failed.append({"chunk_id": item["chunk_id"], "error": str(exc)})
        else:
            # Concurrency is user-controlled: taxonomy_chunk_batch_size.
            # For full batches this equals the configured batch size.
            max_workers = max(1, min(effective_chunk_batch_size, len(batch_items)))
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_map = {executor.submit(_generate_for_item, item): item for item in batch_items}
                for future in as_completed(future_map):
                    item = future_map[future]
                    try:
                        batch_results.append(future.result())
                    except Exception as exc:
                        failed.append({"chunk_id": item["chunk_id"], "error": str(exc)})

        for result in batch_results:
            chunk_id = str(result.get("chunk_id") or "")
            taxonomy_payload = result.get("taxonomy_payload")
            row = result.get("row") or {}
            if not isinstance(taxonomy_payload, dict):
                failed.append({"chunk_id": chunk_id, "error": "invalid_taxonomy_payload"})
                continue
            try:
                repo.upsert_embed_record(
                    {
                        "owner_id": owner_id,
                        "project_id": payload.project_id,
                        "document_id": row.get("document_id"),
                        "chunk_id": chunk_id,
                        "chunk_index": row.get("chunk_index"),
                        "chunk_hash": result.get("chunk_hash"),
                        "taxonomy_tree": taxonomy_payload.get("tree", []),
                        "leaf_ids": taxonomy_payload.get("leaf_ids", []),
                        "taxonomy_provider": provider,
                        "taxonomy_model": model_name,
                        "generation_mode": expected_generation_mode,
                    }
                )
                if bool(result.get("existing")):
                    updated += 1
                else:
                    generated += 1
            except Exception as exc:
                failed.append({"chunk_id": chunk_id, "error": str(exc)})

        logger.debug(
            "DEBUG: embed_chunk_taxonomy_batch_done batch=%s/%s generated=%s updated=%s failed=%s",
            batch_index,
            total_batches,
            generated,
            updated,
            len(failed),
        )

    materialized_taxonomy_id: Optional[str] = None
    if payload.project_id:
        try:
            materialized_taxonomy_id = _upsert_embedding_project_taxonomy(owner_id, payload.project_id)
        except Exception as exc:
            logger.warning(
                "Failed to materialize embedding taxonomy for project_id=%s: %s",
                payload.project_id,
                exc,
            )

    return {
        "updated": True,
        "mode": "chunk",
        "provider": provider,
        "model": model_name,
        "anchor_main_topic": anchor_main_topic,
        "taxonomy_chunk_batch_size": effective_chunk_batch_size,
        "taxonomy_batches_processed": total_batches,
        "pending_chunks": len(pending_rows),
        "chunk_count": len(chunks),
        "generated": generated,
        "updated_existing": updated,
        "skipped": skipped,
        "materialized_taxonomy_id": materialized_taxonomy_id,
        "failed": failed[:10],
    }


def _load_embed_taxonomy_lookup(owner_id: str, chunks: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    chunk_ids = [str(c.get("id")) for c in chunks if c.get("id")]
    if not chunk_ids:
        return {}

    repo = EmbedRepository(owner_id)
    rows = repo.get_embed_by_chunk_ids(chunk_ids)
    lookup: Dict[str, Dict[str, Any]] = {}
    for chunk_id, row in rows.items():
        if not isinstance(row, dict):
            continue
        parsed = dict(row)
        parsed["taxonomy_tree"] = _json_loads_safe(parsed.get("taxonomy_tree"), [])
        parsed["leaf_ids"] = _json_loads_safe(parsed.get("leaf_ids"), [])
        lookup[str(chunk_id)] = parsed
    return lookup


def _embed_record_to_taxonomy_context(embed_record: Dict[str, Any]) -> Dict[str, Any]:
    tree = embed_record.get("taxonomy_tree")
    if not isinstance(tree, list):
        tree = _json_loads_safe(tree, [])
    leaf_ids = embed_record.get("leaf_ids")
    if not isinstance(leaf_ids, list):
        leaf_ids = _json_loads_safe(leaf_ids, [])

    first_node_keys: List[str] = []
    if tree and isinstance(tree[0], dict):
        first_node_keys = sorted(list(tree[0].keys()))
    logger.debug(
        "DEBUG: taxonomy_tree_payload_shape nodes=%s first_node_keys=%s leaf_ids=%s",
        len(tree) if isinstance(tree, list) else 0,
        first_node_keys,
        len(leaf_ids) if isinstance(leaf_ids, list) else 0,
    )

    return {
        "tree": tree or [],
        "leaf_ids": leaf_ids or [],
    }


def _taxonomy_mode_for_request(owner_id: str, payload: "EmbedIndexRequest") -> str:
    cfg = EmbeddingPluginConfig.load(owner_id)
    mode = (payload.taxonomy_mode or cfg.taxonomy_mode or "chunk").strip().lower()
    return mode if mode in {"chunk", "legacy"} else "chunk"


def _chunk_annotation_lookup(taxonomy_data: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    cache = taxonomy_data.get("_chunk_annotation_lookup")
    if isinstance(cache, dict):
        return cache

    structure = taxonomy_data.get("taxonomy_structure")
    if not isinstance(structure, dict):
        return {}

    annotations = structure.get("chunk_annotations")
    if not isinstance(annotations, list):
        return {}

    lookup: Dict[str, Dict[str, Any]] = {}
    for item in annotations:
        if not isinstance(item, dict):
            continue
        chunk_id = str(item.get("chunk_id") or "").strip()
        if chunk_id:
            lookup[chunk_id] = item

    taxonomy_data["_chunk_annotation_lookup"] = lookup
    return lookup


def _annotation_to_taxonomy_context(annotation: Dict[str, Any], taxonomy_data: Dict[str, Any]) -> Dict[str, Any]:
    taxonomy_name = str(taxonomy_data.get("taxonomy_name") or "").strip().lower()
    taxonomy_root_name = _taxonomy_root_name(taxonomy_data).lower()
    cleaned_paths: List[str] = []
    for raw_path in annotation.get("matched_paths", []) or []:
        if not isinstance(raw_path, str):
            continue
        segments = [s.strip() for s in raw_path.split(">") if s.strip()]
        if taxonomy_root_name and segments and segments[0].lower() == taxonomy_root_name:
            segments = segments[1:]
        elif taxonomy_name and segments and segments[0].lower() == taxonomy_name:
            segments = segments[1:]
        if segments:
            cleaned_paths.append(" > ".join(segments))
    cleaned_paths = list(dict.fromkeys(cleaned_paths))

    recomputed_parent_tags: List[str] = []
    for path in cleaned_paths:
        segments = [s.strip() for s in path.split(">") if s.strip()]
        if len(segments) > 1:
            recomputed_parent_tags.extend(segments[:-1])
    recomputed_parent_tags = list(dict.fromkeys(recomputed_parent_tags))

    return {
        "taxonomy_version_id": taxonomy_data.get("taxonomy_id"),
        "taxonomy_name": taxonomy_data.get("taxonomy_name"),
        "matched_leaf_ids": annotation.get("matched_leaf_ids", []),
        "matched_leaf_names": annotation.get("matched_leaf_names", []),
        "matched_paths": cleaned_paths,
        "parent_tags": recomputed_parent_tags,
        "taxonomy_confidence": annotation.get("taxonomy_confidence"),
    }


def _persist_chunk_annotations(
    owner_id: str,
    project_id: str,
    taxonomy_id: Optional[str],
    taxonomy_data: Dict[str, Any],
    chunks: List[Dict[str, Any]],
) -> None:
    """Persist chunk-specific taxonomy annotations into taxonomy structure JSON."""
    if not taxonomy_id or not taxonomy_data:
        return

    project_record = ProjectRepository(owner_id).get_project_by_id(project_id) if project_id else None
    document_map: Dict[str, Dict[str, Any]] = {}
    for d in _list_project_documents(owner_id, project_id):
        document_map[str(d.get("id"))] = d

    annotations: List[Dict[str, Any]] = []
    for row in chunks:
        metadata = _normalize_metadata(row.get("metadata"))
        text = _resolve_chunk_text(row, metadata)
        if not text:
            continue

        taxonomy_context = _derive_taxonomy_context(text, taxonomy_data)
        if not taxonomy_context:
            continue

        annotation_payload = _build_embedding_payload(
            row,
            project_record,
            document_map,
            include_taxonomy=True,
            taxonomy_data=taxonomy_data,
            taxonomy_mode="legacy",
        )
        annotation_metadata = annotation_payload.get("metadata", {})
        annotations.append(
            {
                "chunk_id": str(row.get("id")),
                "document_id": str(row.get("document_id") or ""),
                "chunk_index": row.get("chunk_index"),
                "matched_leaf_ids": taxonomy_context.get("matched_leaf_ids", []),
                "matched_leaf_names": taxonomy_context.get("matched_leaf_names", []),
                "matched_paths": taxonomy_context.get("matched_paths", []),
                "parent_tags": taxonomy_context.get("parent_tags", []),
                "taxonomy_confidence": taxonomy_context.get("taxonomy_confidence"),
                "embedding_metadata": {
                    "taxonomy_leaf_tags": annotation_metadata.get("taxonomy_leaf_tags", []),
                    "taxonomy_parent_tags": annotation_metadata.get("taxonomy_parent_tags", []),
                    "taxonomy_path_tags": annotation_metadata.get("taxonomy_path_tags", []),
                },
            }
        )

    if not annotations:
        return

    repo = TaxonomyRepository(owner_id)
    tax_record = repo.get_taxonomy_by_id(taxonomy_id)
    if not tax_record:
        return

    structure = _normalize_taxonomy_structure(tax_record.get("structure"))

    merged: Dict[str, Dict[str, Any]] = {}
    existing = structure.get("chunk_annotations") if isinstance(structure, dict) else None
    if isinstance(existing, list):
        for item in existing:
            if not isinstance(item, dict):
                continue
            chunk_id = str(item.get("chunk_id") or "").strip()
            if chunk_id:
                merged[chunk_id] = item

    for item in annotations:
        chunk_id = str(item.get("chunk_id") or "").strip()
        if chunk_id:
            merged[chunk_id] = item

    merged_annotations = list(merged.values())
    merged_annotations.sort(
        key=lambda item: (
            str(item.get("document_id") or ""),
            int(item.get("chunk_index") or 0),
            str(item.get("chunk_id") or ""),
        )
    )

    structure["chunk_annotations"] = merged_annotations
    repo.update_taxonomy_structure(taxonomy_id, structure)


@dataclass
class EmbeddingPluginConfig:
    qdrant_url: str
    collection: str
    ollama_url: str
    ollama_model: str
    distance: str
    batch_size: int
    include_taxonomy: bool
    taxonomy_mode: str
    preprocess_policy: str
    taxonomy_generator: str
    taxonomy_processing_mode: str
    taxonomy_anchor_main_topic: bool
    taxonomy_chunk_batch_size: int
    segment_token_size: int
    segment_overlap_tokens: int
    skip_segmentation: bool

    @classmethod
    def load(cls, owner_id: Optional[str]) -> "EmbeddingPluginConfig":
        s = _settings(owner_id)
        segment_token_size = _coerce_segment_token_size(s.get_setting("embedding_segment_token_size", 512), 512)
        segment_overlap_tokens = _coerce_segment_overlap_tokens(
            s.get_setting("embedding_segment_overlap_tokens", _default_segment_overlap_tokens(segment_token_size)),
            segment_token_size,
            _default_segment_overlap_tokens(segment_token_size),
        )
        return cls(
            qdrant_url=str(s.get_setting("embedding_qdrant_url", "http://localhost:6333")),
            collection=str(s.get_setting("embedding_qdrant_collection", "compileo_chunks")),
            ollama_url=str(s.get_setting("embedding_ollama_url", s.get_ollama_base_url())),
            ollama_model=str(s.get_setting("embedding_ollama_model", "nomic-embed-text")),
            distance=str(s.get_setting("embedding_distance", "Cosine")),
            batch_size=max(1, _coerce_int(s.get_setting("embedding_batch_size", 128), 128)),
            include_taxonomy=_coerce_bool(s.get_setting("embedding_include_taxonomy", True), True),
            taxonomy_mode=str(s.get_setting("embedding_taxonomy_mode", "chunk")),
            preprocess_policy=str(s.get_setting("embedding_preprocess_policy", "markdown_preserve_headings")),
            taxonomy_generator=str(s.get_setting("embedding_taxonomy_generator", "gemini")),
            taxonomy_processing_mode=str(s.get_setting("embedding_taxonomy_processing_mode", "fast")),
            taxonomy_anchor_main_topic=_coerce_bool(s.get_setting("embedding_taxonomy_anchor_main_topic", True), True),
            taxonomy_chunk_batch_size=_coerce_taxonomy_chunk_batch_size(
                s.get_setting("embedding_taxonomy_chunk_batch_size", 10),
                10,
            ),
            segment_token_size=segment_token_size,
            segment_overlap_tokens=segment_overlap_tokens,
            skip_segmentation=_coerce_bool(s.get_setting("embedding_skip_segmentation", False), False),
        )

    def save(self, owner_id: Optional[str]) -> None:
        s = _settings(owner_id)
        s.set_setting("embedding_qdrant_url", self.qdrant_url)
        s.set_setting("embedding_qdrant_collection", self.collection)
        s.set_setting("embedding_ollama_url", self.ollama_url)
        s.set_setting("embedding_ollama_model", self.ollama_model)
        s.set_setting("embedding_distance", self.distance)
        s.set_setting("embedding_batch_size", self.batch_size)
        s.set_setting("embedding_include_taxonomy", self.include_taxonomy)
        s.set_setting("embedding_taxonomy_mode", self.taxonomy_mode)
        s.set_setting("embedding_preprocess_policy", self.preprocess_policy)
        s.set_setting("embedding_taxonomy_generator", self.taxonomy_generator)
        s.set_setting("embedding_taxonomy_processing_mode", self.taxonomy_processing_mode)
        s.set_setting("embedding_taxonomy_anchor_main_topic", self.taxonomy_anchor_main_topic)
        s.set_setting(
            "embedding_taxonomy_chunk_batch_size",
            _coerce_taxonomy_chunk_batch_size(self.taxonomy_chunk_batch_size, 10),
        )
        s.set_setting("embedding_segment_token_size", _coerce_segment_token_size(self.segment_token_size, 512))
        s.set_setting(
            "embedding_segment_overlap_tokens",
            _coerce_segment_overlap_tokens(
                self.segment_overlap_tokens,
                _coerce_segment_token_size(self.segment_token_size, 512),
                _default_segment_overlap_tokens(_coerce_segment_token_size(self.segment_token_size, 512)),
            ),
        )
        s.set_setting("embedding_skip_segmentation", _coerce_bool(self.skip_segmentation, False))


class EmbeddingSettingsRequest(BaseModel):
    qdrant_url: str = Field(default="http://localhost:6333")
    collection: str = Field(default="compileo_chunks")
    ollama_url: str = Field(default="http://localhost:11434")
    ollama_model: str = Field(default="nomic-embed-text")
    distance: str = Field(default="Cosine")
    batch_size: int = Field(default=128, ge=1, le=4096)
    include_taxonomy: bool = Field(default=True)
    taxonomy_mode: str = Field(default="chunk")
    preprocess_policy: str = Field(default="markdown_preserve_headings")
    taxonomy_generator: str = Field(default="gemini")
    taxonomy_processing_mode: str = Field(default="fast")
    taxonomy_anchor_main_topic: bool = Field(default=True)
    taxonomy_chunk_batch_size: int = Field(default=10, ge=1, le=256)
    segment_token_size: int = Field(default=512, ge=64, le=4096)
    segment_overlap_tokens: int = Field(default=80, ge=0, le=4096)
    skip_segmentation: bool = Field(default=False)


class EmbedIndexRequest(BaseModel):
    project_id: Optional[str] = None
    document_id: Optional[str] = None
    document_ids: List[str] = Field(default_factory=list)
    chunk_ids: List[str] = Field(default_factory=list)
    include_taxonomy: Optional[bool] = None
    taxonomy_mode: Optional[str] = None
    auto_generate_taxonomy: bool = True
    taxonomy_generator: Optional[str] = None
    taxonomy_processing_mode: Optional[str] = None
    taxonomy_anchor_main_topic: Optional[bool] = None
    taxonomy_chunk_batch_size: Optional[int] = Field(default=None, ge=1, le=256)
    collection: Optional[str] = None
    model: Optional[str] = None
    segment_token_size: Optional[int] = Field(default=None, ge=64, le=4096)
    segment_overlap_tokens: Optional[int] = Field(default=None, ge=0, le=4096)
    skip_segmentation: Optional[bool] = None
    dry_run: bool = False


def _list_project_documents(owner_id: str, project_id: str) -> List[Dict[str, Any]]:
    return DocumentRepository(owner_id).get_documents_by_project_id(project_id)


def _count_chunks_by_document(owner_id: str, document_ids: List[str]) -> Dict[str, int]:
    if not document_ids:
        return {}
    repo = ChunkRepository(owner_id)
    placeholders = ",".join(["?"] * len(document_ids))
    query = f"""
        SELECT document_id, COUNT(*) as cnt
        FROM chunks
        WHERE owner_id = ? AND document_id IN ({placeholders})
        GROUP BY document_id
    """
    with repo.cursor() as cursor:
        cursor.execute(query, [owner_id] + document_ids)
        rows = cursor.fetchall() or []
    return {str(r[0]): int(r[1]) for r in rows}


def _scope_snapshot(owner_id: str, project_id: Optional[str], document_ids: Optional[List[str]] = None) -> Dict[str, Any]:
    cfg = EmbeddingPluginConfig.load(owner_id)
    projects = ProjectRepository(owner_id).get_all_projects()
    scope: Dict[str, Any] = {
        "projects": [{"id": str(p.get("id")), "name": p.get("name", "") } for p in projects],
        "documents": [],
        "taxonomy": {"exists": False, "count": 0, "latest_id": None, "latest_name": None},
        "chunk_taxonomy": {
            "scope_type": "project_all_documents",
            "document_filter_applied": False,
            "scope_document_count": 0,
            "scope_chunk_count": 0,
            "chunks_with_embed_taxonomy": 0,
            "missing_chunks": 0,
            "coverage_ratio": 0.0,
            "fully_generated": False,
        },
        "ollama_models": _fetch_ollama_models(cfg.ollama_url),
    }

    if not project_id:
        return scope

    documents = _list_project_documents(owner_id, project_id)
    counts = _count_chunks_by_document(owner_id, [str(d.get("id")) for d in documents])
    scope["documents"] = [
        {
            "id": str(d.get("id")),
            "name": d.get("file_name", ""),
            "source_file_path": d.get("source_file_path"),
            "chunk_count": counts.get(str(d.get("id")), 0),
        }
        for d in documents
    ]

    taxonomies = TaxonomyRepository(owner_id).get_taxonomies_by_project(project_id)
    if taxonomies:
        latest = taxonomies[0]
        scope["taxonomy"] = {
            "exists": True,
            "count": len(taxonomies),
            "latest_id": latest.get("id"),
            "latest_name": latest.get("name"),
        }

    filtered_document_ids: List[str] = []
    if isinstance(document_ids, list) and document_ids:
        valid_doc_ids = {str(d.get("id")) for d in documents if d.get("id")}
        for doc_id in document_ids:
            doc_id_str = str(doc_id or "").strip()
            if doc_id_str and doc_id_str in valid_doc_ids:
                filtered_document_ids.append(doc_id_str)
        # Preserve user order while deduplicating.
        filtered_document_ids = list(dict.fromkeys(filtered_document_ids))

    chunk_repo = ChunkRepository(owner_id)
    doc_filter_applied = bool(filtered_document_ids)
    scope_document_count = len(filtered_document_ids) if doc_filter_applied else len(documents)

    if doc_filter_applied:
        placeholders = ",".join(["?"] * len(filtered_document_ids))
        doc_filter_sql = f" AND c.document_id IN ({placeholders})"
        doc_filter_params = list(filtered_document_ids)
    else:
        doc_filter_sql = ""
        doc_filter_params = []

    with chunk_repo.cursor() as cursor:
        cursor.execute(
            f"""
            SELECT COUNT(*)
            FROM chunks c
            JOIN documents d ON d.id = c.document_id
            WHERE c.owner_id = ? AND d.owner_id = ? AND d.project_id = ?
            {doc_filter_sql}
            """,
            [owner_id, owner_id, project_id] + doc_filter_params,
        )
        scope_chunk_count = int((cursor.fetchone() or [0])[0] or 0)

        cursor.execute(
            f"""
            SELECT COUNT(*)
            FROM embed e
            JOIN chunks c ON c.id = e.chunk_id
            JOIN documents d ON d.id = c.document_id
            WHERE e.owner_id = ? AND c.owner_id = ? AND d.owner_id = ? AND d.project_id = ?
            {doc_filter_sql}
            """,
            [owner_id, owner_id, owner_id, project_id] + doc_filter_params,
        )
        chunks_with_embed_taxonomy = int((cursor.fetchone() or [0])[0] or 0)

    missing_chunks = max(0, scope_chunk_count - chunks_with_embed_taxonomy)
    scope["chunk_taxonomy"] = {
        "scope_type": "document_selection" if doc_filter_applied else "project_all_documents",
        "document_filter_applied": doc_filter_applied,
        "scope_document_count": scope_document_count,
        "scope_chunk_count": scope_chunk_count,
        "chunks_with_embed_taxonomy": chunks_with_embed_taxonomy,
        "missing_chunks": missing_chunks,
        "coverage_ratio": round(chunks_with_embed_taxonomy / scope_chunk_count, 4) if scope_chunk_count else 0.0,
        "fully_generated": bool(scope_chunk_count > 0 and missing_chunks == 0),
    }

    logger.debug(
        "DEBUG: embedding_scope_snapshot project_id=%s taxonomy_mode=%s documents=%s taxonomy_exists=%s taxonomy_count=%s latest_taxonomy_name=%s latest_taxonomy_id=%s note=project_level_taxonomy_status",
        project_id,
        cfg.taxonomy_mode,
        len(documents),
        bool(scope.get("taxonomy", {}).get("exists")),
        int(scope.get("taxonomy", {}).get("count") or 0),
        scope.get("taxonomy", {}).get("latest_name"),
        scope.get("taxonomy", {}).get("latest_id"),
    )
    logger.debug(
        "DEBUG: embedding_chunk_taxonomy_scope project_id=%s scope_type=%s document_filter_applied=%s scope_document_count=%s scope_chunk_count=%s chunks_with_embed_taxonomy=%s missing_chunks=%s coverage_ratio=%s",
        project_id,
        scope.get("chunk_taxonomy", {}).get("scope_type"),
        scope.get("chunk_taxonomy", {}).get("document_filter_applied"),
        scope.get("chunk_taxonomy", {}).get("scope_document_count"),
        scope.get("chunk_taxonomy", {}).get("scope_chunk_count"),
        scope.get("chunk_taxonomy", {}).get("chunks_with_embed_taxonomy"),
        scope.get("chunk_taxonomy", {}).get("missing_chunks"),
        scope.get("chunk_taxonomy", {}).get("coverage_ratio"),
    )
    return scope


def _load_chunks_for_request(owner_id: str, payload: EmbedIndexRequest) -> List[Dict[str, Any]]:
    repo = ChunkRepository(owner_id)

    if payload.chunk_ids:
        rows: List[Dict[str, Any]] = []
        for chunk_id in payload.chunk_ids:
            row = repo.get_chunk_by_id(chunk_id)
            if row:
                rows.append(row)
        return rows

    document_ids: List[str] = []
    if payload.document_ids:
        document_ids = payload.document_ids
    elif payload.document_id:
        document_ids = [payload.document_id]

    if document_ids:
        rows: List[Dict[str, Any]] = []
        for document_id in document_ids:
            rows.extend(repo.get_chunks_by_document(document_id))
        return rows

    if payload.project_id:
        with repo.cursor() as cursor:
            cursor.execute(
                """
                SELECT c.*
                FROM chunks c
                JOIN documents d ON d.id = c.document_id
                WHERE d.project_id = ? AND c.owner_id = ?
                ORDER BY c.created_at ASC
                """,
                (payload.project_id, owner_id),
            )
            rows = cursor.fetchall()
            return [dict(r) for r in rows] if rows else []

    return []


def _taxonomy_context_from_legacy(taxonomy_context: Dict[str, Any]) -> Dict[str, Any]:
    matched_paths = taxonomy_context.get("matched_paths") if isinstance(taxonomy_context, dict) else []
    if not isinstance(matched_paths, list):
        matched_paths = []

    root_children: List[Dict[str, Any]] = []

    for raw_path in matched_paths:
        if not isinstance(raw_path, str):
            continue
        segments = [s.strip() for s in raw_path.split(">") if s.strip()]
        if not segments:
            continue

        current_children = root_children
        for segment in segments:
            found_node = next(
                (
                    c
                    for c in current_children
                    if isinstance(c, dict) and str(c.get("name") or "").strip() == segment
                ),
                None,
            )
            next_node: Dict[str, Any]
            if isinstance(found_node, dict):
                next_node = found_node
            else:
                next_node = {"name": segment}
                current_children.append(next_node)
            children_raw = next_node.get("children")
            children_list = children_raw if isinstance(children_raw, list) else []
            if "children" not in next_node:
                next_node["children"] = children_list
            current_children = [child for child in children_list if isinstance(child, dict)]

    tree = root_children
    leaf_ids = taxonomy_context.get("matched_leaf_ids", []) if isinstance(taxonomy_context, dict) else []
    if not isinstance(leaf_ids, list):
        leaf_ids = []

    return {
        "tree": tree,
        "leaf_ids": leaf_ids,
    }


def _taxonomy_snapshot(owner_id: str, project_id: Optional[str]) -> Dict[str, Any]:
    if not project_id:
        return {}
    repo = TaxonomyRepository(owner_id)
    taxonomies = repo.get_taxonomies_by_project(project_id)
    if not taxonomies:
        return {}
    latest = taxonomies[0]
    structure = _normalize_taxonomy_structure(latest.get("structure"))
    return {
        "taxonomy_id": latest.get("id"),
        "taxonomy_name": latest.get("name"),
        "taxonomy_structure": structure or {},
    }


async def _ensure_taxonomy_exists(
    owner_id: str,
    current_user: UserSchema,
    payload: EmbedIndexRequest,
) -> Dict[str, Any]:
    if not payload.include_taxonomy:
        return {"exists": False, "generated": False, "reason": "disabled"}
    if not payload.project_id:
        raise ValueError("project_id is required when include_taxonomy is enabled")

    existing = TaxonomyRepository(owner_id).get_taxonomies_by_project(payload.project_id)
    if existing:
        latest = existing[0]
        return {
            "exists": True,
            "generated": False,
            "taxonomy_id": latest.get("id"),
            "taxonomy_name": latest.get("name"),
        }

    if not payload.auto_generate_taxonomy:
        return {"exists": False, "generated": False, "reason": "missing_and_auto_generation_disabled"}

    document_ids = list(payload.document_ids)
    if not document_ids and payload.document_id:
        document_ids = [payload.document_id]
    if not document_ids:
        docs = _list_project_documents(owner_id, payload.project_id)
        document_ids = [str(d.get("id")) for d in docs if d.get("id")]

    if not document_ids:
        raise ValueError("Cannot auto-generate taxonomy: no documents available in selected scope")

    cfg = EmbeddingPluginConfig.load(owner_id)
    generator = payload.taxonomy_generator or cfg.taxonomy_generator
    processing_mode = payload.taxonomy_processing_mode or cfg.taxonomy_processing_mode

    from fastapi import BackgroundTasks
    from src.compileo.api.routes.taxonomy import TaxonomyGenerateRequest, generate_taxonomy
    from src.compileo.storage.src.database import get_tenant_db_connection

    generate_request = TaxonomyGenerateRequest(
        project_id=payload.project_id,
        name=f"Auto-taxonomy for embeddings ({payload.project_id})",
        documents=document_ids,
        depth=3,
        generator=generator,
        domain="general",
        batch_size=10,
        specificity_level=1,
        processing_mode=processing_mode,
    )

    with get_tenant_db_connection(owner_id) as conn:
        result = await generate_taxonomy(
            request=generate_request,
            background_tasks=BackgroundTasks(),
            db=conn,
            current_user=current_user,
        )

    refreshed = TaxonomyRepository(owner_id).get_taxonomies_by_project(payload.project_id)
    if refreshed:
        latest = refreshed[0]
        return {
            "exists": True,
            "generated": True,
            "taxonomy_id": latest.get("id"),
            "taxonomy_name": latest.get("name"),
            "generation_result": result,
        }

    return {"exists": False, "generated": True, "reason": "generation_returned_no_saved_taxonomy"}


async def _ensure_chunk_annotations(
    owner_id: str,
    payload: EmbedIndexRequest,
    chunks: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Ensure taxonomy metadata exists for selected chunks based on configured mode."""
    mode = _taxonomy_mode_for_request(owner_id, payload)
    if mode == "chunk":
        try:
            return _ensure_embed_taxonomy_records(owner_id, payload, chunks)
        except Exception as exc:
            return {
                "updated": False,
                "mode": "chunk",
                "reason": "generation_failed",
                "error": str(exc),
            }

    if not payload.project_id:
        return {"updated": False, "reason": "missing_project_id", "mode": "legacy"}

    taxonomy_data = _taxonomy_snapshot(owner_id, payload.project_id)
    taxonomy_id = taxonomy_data.get("taxonomy_id")
    if not taxonomy_id:
        return {"updated": False, "reason": "no_taxonomy", "mode": "legacy"}

    structure = taxonomy_data.get("taxonomy_structure") or {}
    existing = structure.get("chunk_annotations") if isinstance(structure, dict) else None
    existing_count = len(existing) if isinstance(existing, list) else 0
    if not chunks:
        return {"updated": False, "reason": "no_chunks", "count": existing_count, "mode": "legacy"}

    _persist_chunk_annotations(
        owner_id=owner_id,
        project_id=payload.project_id,
        taxonomy_id=taxonomy_id,
        taxonomy_data=taxonomy_data,
        chunks=chunks,
    )
    return {
        "updated": True,
        "mode": "legacy",
        "taxonomy_id": taxonomy_id,
        "chunk_count": len(chunks),
        "previous_annotation_count": existing_count,
    }


def _build_embedding_payload(
    chunk_row: Dict[str, Any],
    project_record: Optional[Dict[str, Any]],
    document_map: Dict[str, Dict[str, Any]],
    include_taxonomy: bool,
    taxonomy_data: Dict[str, Any],
    taxonomy_mode: str = "chunk",
    embed_lookup: Optional[Dict[str, Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    metadata = _normalize_metadata(chunk_row.get("metadata"))
    text = _resolve_chunk_text(chunk_row, metadata)

    document_id = str(chunk_row.get("document_id") or "")
    document = document_map.get(document_id, {})
    source = (
        metadata.get("source")
        or metadata.get("source_file_path")
        or document.get("source_file_path")
        or ""
    )

    page_range_raw = metadata.get("page_range")
    page_range = page_range_raw if isinstance(page_range_raw, dict) else {}
    page_start = metadata.get("page_start") or page_range.get("start")
    page_end = metadata.get("page_end") or page_range.get("end")

    payload_metadata: Dict[str, Any] = {
        "project_id": str(project_record.get("id")) if project_record else None,
        "project_name": project_record.get("name") if project_record else None,
        "document_id": document_id,
        "document_name": document.get("file_name"),
        "chunk_index": chunk_row.get("chunk_index"),
        "chunk_strategy": chunk_row.get("chunk_strategy"),
        "source": source,
        "page_start": page_start,
        "page_end": page_end,
    }

    if include_taxonomy:
        taxonomy_context: Dict[str, Any] = {}
        taxonomy_source = "none"
        effective_taxonomy_mode = (taxonomy_mode or "chunk").strip().lower()
        chunk_id = str(chunk_row.get("id") or "")
        if chunk_id and isinstance(embed_lookup, dict):
            embed_record = embed_lookup.get(chunk_id)
            if isinstance(embed_record, dict):
                taxonomy_context = _embed_record_to_taxonomy_context(embed_record)
                taxonomy_source = "embed_chunk_cache"

        # In chunk mode, taxonomy should come exclusively from embed chunk cache.
        # This prevents cross-document fallback to project-level legacy taxonomy.
        if effective_taxonomy_mode != "chunk" and chunk_id and not taxonomy_context:
            lookup = _chunk_annotation_lookup(taxonomy_data)
            annotation = lookup.get(chunk_id)
            if isinstance(annotation, dict):
                taxonomy_context = _annotation_to_taxonomy_context(annotation, taxonomy_data)
                taxonomy_source = "legacy_chunk_annotation"

        if effective_taxonomy_mode != "chunk" and not taxonomy_context and taxonomy_data:
            taxonomy_context = _derive_taxonomy_context(text, taxonomy_data)
            if taxonomy_context:
                taxonomy_context = _taxonomy_context_from_legacy(taxonomy_context)
                taxonomy_source = "legacy_project_taxonomy_derived"

        if taxonomy_context:
            payload_metadata["taxonomy"] = taxonomy_context
            tree = taxonomy_context.get("tree")
            logger.debug(
                "DEBUG: taxonomy_context_attached chunk_id=%s source=%s tree_nodes=%s leaf_ids=%s",
                chunk_id,
                taxonomy_source,
                len(tree) if isinstance(tree, list) else 0,
                len(taxonomy_context.get("leaf_ids") or []),
            )
        else:
            logger.debug(
                "DEBUG: taxonomy_context_missing chunk_id=%s include_taxonomy=%s has_taxonomy_data=%s has_embed_lookup=%s",
                chunk_id,
                include_taxonomy,
                bool(taxonomy_data),
                bool(embed_lookup),
            )

    return {
        "id": chunk_row.get("id"),
        "text": text,
        "metadata": payload_metadata,
    }


def _submit_embedding_job(
    owner_id: str,
    request_payload: EmbedIndexRequest,
    job_manager: Any,
    taxonomy_status: Dict[str, Any],
) -> str:
    extensions = _get_plugin_manager().get_extensions("compileo.job.executor", owner_id=owner_id)
    if "qdrant_embed_index" not in extensions:
        raise ValueError("Embedding executor 'qdrant_embed_index' is not registered")

    from src.compileo.features.jobhandle.models import JobPriority, JobType

    if job_manager is None:
        raise ValueError("Job queue manager is not initialized")

    cfg = EmbeddingPluginConfig.load(owner_id)
    effective_include_taxonomy = cfg.include_taxonomy if request_payload.include_taxonomy is None else request_payload.include_taxonomy
    effective_segment_token_size = _coerce_segment_token_size(
        request_payload.segment_token_size if request_payload.segment_token_size is not None else cfg.segment_token_size,
        cfg.segment_token_size,
    )
    effective_segment_overlap_tokens = _coerce_segment_overlap_tokens(
        request_payload.segment_overlap_tokens if request_payload.segment_overlap_tokens is not None else cfg.segment_overlap_tokens,
        effective_segment_token_size,
        cfg.segment_overlap_tokens,
    )
    effective_taxonomy_chunk_batch_size = _coerce_taxonomy_chunk_batch_size(
        request_payload.taxonomy_chunk_batch_size
        if request_payload.taxonomy_chunk_batch_size is not None
        else cfg.taxonomy_chunk_batch_size,
        cfg.taxonomy_chunk_batch_size,
    )
    effective_skip_segmentation = cfg.skip_segmentation if request_payload.skip_segmentation is None else bool(request_payload.skip_segmentation)

    safe_taxonomy_status = _make_json_safe(taxonomy_status)

    parameters = {
        "owner_id": owner_id,
        "executor_key": "qdrant_embed_index",
        "project_id": request_payload.project_id,
        "document_id": request_payload.document_id,
        "document_ids": request_payload.document_ids,
        "chunk_ids": request_payload.chunk_ids,
        "include_taxonomy": effective_include_taxonomy,
        "taxonomy_mode": _taxonomy_mode_for_request(owner_id, request_payload),
        "taxonomy_generator": request_payload.taxonomy_generator,
        "taxonomy_processing_mode": request_payload.taxonomy_processing_mode,
        "taxonomy_anchor_main_topic": request_payload.taxonomy_anchor_main_topic,
        "taxonomy_chunk_batch_size": effective_taxonomy_chunk_batch_size,
        "taxonomy_status": safe_taxonomy_status,
        "collection": request_payload.collection or cfg.collection,
        "model": request_payload.model or cfg.ollama_model,
        "segment_token_size": effective_segment_token_size,
        "segment_overlap_tokens": effective_segment_overlap_tokens,
        "skip_segmentation": effective_skip_segmentation,
        "dry_run": request_payload.dry_run,
        "config_snapshot": {
            "qdrant_url": cfg.qdrant_url,
            "ollama_url": cfg.ollama_url,
            "distance": cfg.distance,
            "batch_size": cfg.batch_size,
            "taxonomy_chunk_batch_size": cfg.taxonomy_chunk_batch_size,
            "segment_token_size": cfg.segment_token_size,
            "segment_overlap_tokens": cfg.segment_overlap_tokens,
            "skip_segmentation": cfg.skip_segmentation,
            "preprocess_policy": cfg.preprocess_policy,
        },
    }

    return job_manager.submit_job(
        job_type=JobType.PLUGIN_TASK,
        parameters=parameters,
        priority=JobPriority.NORMAL,
        user_id=owner_id,
    )


@plugin_router.get("/settings")
async def get_embedding_settings(current_user: UserSchema = Depends(get_current_active_user)):
    cfg = EmbeddingPluginConfig.load(current_user.id)
    return {
        "qdrant_url": cfg.qdrant_url,
        "collection": cfg.collection,
        "ollama_url": cfg.ollama_url,
        "ollama_model": cfg.ollama_model,
        "distance": cfg.distance,
        "batch_size": cfg.batch_size,
        "include_taxonomy": cfg.include_taxonomy,
        "taxonomy_mode": cfg.taxonomy_mode,
        "preprocess_policy": cfg.preprocess_policy,
        "taxonomy_generator": cfg.taxonomy_generator,
        "taxonomy_processing_mode": cfg.taxonomy_processing_mode,
        "taxonomy_anchor_main_topic": cfg.taxonomy_anchor_main_topic,
        "taxonomy_chunk_batch_size": cfg.taxonomy_chunk_batch_size,
        "segment_token_size": cfg.segment_token_size,
        "segment_overlap_tokens": cfg.segment_overlap_tokens,
        "skip_segmentation": cfg.skip_segmentation,
    }


@plugin_router.post("/settings")
async def save_embedding_settings(
    payload: EmbeddingSettingsRequest,
    current_user: UserSchema = Depends(get_current_active_user),
):
    cfg = EmbeddingPluginConfig(
        qdrant_url=payload.qdrant_url,
        collection=payload.collection,
        ollama_url=payload.ollama_url,
        ollama_model=payload.ollama_model,
        distance=payload.distance,
        batch_size=payload.batch_size,
        include_taxonomy=payload.include_taxonomy,
        taxonomy_mode=(payload.taxonomy_mode or "chunk").strip().lower(),
        preprocess_policy=payload.preprocess_policy,
        taxonomy_generator=payload.taxonomy_generator,
        taxonomy_processing_mode=payload.taxonomy_processing_mode,
        taxonomy_anchor_main_topic=payload.taxonomy_anchor_main_topic,
        taxonomy_chunk_batch_size=_coerce_taxonomy_chunk_batch_size(payload.taxonomy_chunk_batch_size, 10),
        segment_token_size=_coerce_segment_token_size(payload.segment_token_size, 512),
        segment_overlap_tokens=_coerce_segment_overlap_tokens(
            payload.segment_overlap_tokens,
            _coerce_segment_token_size(payload.segment_token_size, 512),
            80,
        ),
        skip_segmentation=payload.skip_segmentation,
    )
    cfg.save(current_user.id)
    return {"status": "ok", "message": "Embedding settings saved"}


@plugin_router.get("/scope")
async def get_scope(
    project_id: Optional[str] = None,
    document_ids: Optional[str] = None,
    current_user: UserSchema = Depends(get_current_active_user),
):
    parsed_document_ids: Optional[List[str]] = None
    if isinstance(document_ids, str) and document_ids.strip():
        parsed_document_ids = [doc_id.strip() for doc_id in document_ids.split(",") if doc_id.strip()]
    return _scope_snapshot(current_user.id, project_id, parsed_document_ids)


@plugin_router.post("/index")
async def index_chunks(
    request: Request,
    payload: EmbedIndexRequest,
    current_user: UserSchema = Depends(get_current_active_user),
):
    if not payload.project_id:
        raise HTTPException(status_code=400, detail="project_id is required")
    try:
        logger.debug(
            "DEBUG: embeddings/index called owner_id=%s project_id=%s include_taxonomy=%s dry_run=%s",
            current_user.id,
            payload.project_id,
            payload.include_taxonomy,
            payload.dry_run,
        )
        effective_include_taxonomy = (
            EmbeddingPluginConfig.load(current_user.id).include_taxonomy
            if payload.include_taxonomy is None
            else payload.include_taxonomy
        )

        taxonomy_mode = _taxonomy_mode_for_request(current_user.id, payload)
        taxonomy_status: Dict[str, Any]
        if effective_include_taxonomy and taxonomy_mode == "legacy":
            taxonomy_status = await _ensure_taxonomy_exists(current_user.id, current_user, payload)
        elif effective_include_taxonomy and taxonomy_mode == "chunk":
            taxonomy_status = {
                "exists": False,
                "generated": False,
                "mode": "chunk",
                "reason": "embed_chunk_taxonomy_mode",
            }
        else:
            taxonomy_status = {"exists": False, "generated": False, "reason": "taxonomy_disabled"}

        # Keep submit path non-blocking: defer chunk-mode taxonomy annotation
        # and embed lookup generation to background executor.
        annotation_status: Dict[str, Any] = {
            "updated": False,
            "deferred": True,
            "reason": "deferred_to_executor",
            "mode": _taxonomy_mode_for_request(current_user.id, payload),
        }

        job_id = _submit_embedding_job(
            current_user.id,
            payload,
            getattr(request.app.state, "job_queue_manager", None),
            taxonomy_status,
        )
        return {
            "status": "submitted",
            "job_id": job_id,
            "executor_key": "qdrant_embed_index",
            "taxonomy_status": taxonomy_status,
            "annotation_status": annotation_status,
        }
    except Exception as exc:
        logger.exception(
            "ERROR: embeddings/index failed owner_id=%s project_id=%s error=%s",
            current_user.id,
            payload.project_id,
            exc,
        )
        raise HTTPException(status_code=500, detail=str(exc))


@plugin_router.post("/index/preview")
async def preview_index_payload(
    payload: EmbedIndexRequest,
    current_user: UserSchema = Depends(get_current_active_user),
):
    chunks = _load_chunks_for_request(current_user.id, payload)
    cfg = EmbeddingPluginConfig.load(current_user.id)
    include_taxonomy = cfg.include_taxonomy if payload.include_taxonomy is None else payload.include_taxonomy

    annotation_status: Dict[str, Any] = {"updated": False, "reason": "taxonomy_disabled"}
    embed_lookup: Dict[str, Dict[str, Any]] = {}
    if include_taxonomy and payload.project_id:
        annotation_status = await _ensure_chunk_annotations(current_user.id, payload, chunks)
        if _taxonomy_mode_for_request(current_user.id, payload) == "chunk":
            embed_lookup = _load_embed_taxonomy_lookup(current_user.id, chunks)

    project_record = ProjectRepository(current_user.id).get_project_by_id(payload.project_id) if payload.project_id else None
    document_map: Dict[str, Dict[str, Any]] = {}
    if payload.project_id:
        for d in _list_project_documents(current_user.id, payload.project_id):
            document_map[str(d.get("id"))] = d

    taxonomy_data = _taxonomy_snapshot(current_user.id, payload.project_id) if include_taxonomy else {}
    preview_rows = [
        _build_embedding_payload(
            row,
            project_record,
            document_map,
            include_taxonomy,
            taxonomy_data,
            taxonomy_mode=_taxonomy_mode_for_request(current_user.id, payload),
            embed_lookup=embed_lookup,
        )
        for row in chunks[:10]
    ]
    effective_skip_segmentation = cfg.skip_segmentation if payload.skip_segmentation is None else bool(payload.skip_segmentation)
    effective_segment_token_size = _coerce_segment_token_size(
        payload.segment_token_size if payload.segment_token_size is not None else cfg.segment_token_size,
        cfg.segment_token_size,
    )
    effective_segment_overlap_tokens = _coerce_segment_overlap_tokens(
        payload.segment_overlap_tokens if payload.segment_overlap_tokens is not None else cfg.segment_overlap_tokens,
        effective_segment_token_size,
        cfg.segment_overlap_tokens,
    )
    preview_segments, segment_token_size, segment_overlap_tokens, segmented_parent_count = _expand_payloads_with_micro_segments(
        preview_rows,
        effective_segment_token_size,
        effective_segment_overlap_tokens,
        skip_segmentation=effective_skip_segmentation,
    )
    taxonomy_attached = any(
        isinstance(r.get("metadata", {}).get("taxonomy"), dict)
        and bool(r.get("metadata", {}).get("taxonomy", {}).get("tree"))
        for r in preview_rows
    )
    return {
        "total_chunks": len(chunks),
        "preview_count": len(preview_rows),
        "preview_segment_count": len(preview_segments),
        "segmented_parent_count": segmented_parent_count,
        "segment_token_size": segment_token_size,
        "segment_overlap_tokens": segment_overlap_tokens,
        "skip_segmentation": effective_skip_segmentation,
        "taxonomy_attached": taxonomy_attached,
        "annotation_status": annotation_status,
        "preview": preview_rows,
        "preview_segments": preview_segments[:10],
    }


class QdrantEmbeddingJobExecutor:
    """Background executor for chunk embedding/indexing jobs."""

    def execute(
        self,
        parameters: Dict[str, Any],
        progress_callback=None,
        **_: Any,
    ) -> Dict[str, Any]:
        owner_id = parameters.get("owner_id")
        if not owner_id:
            raise ValueError("owner_id is required for embedding executor")

        request_payload = EmbedIndexRequest(
            project_id=parameters.get("project_id"),
            document_id=parameters.get("document_id"),
            document_ids=parameters.get("document_ids") or [],
            chunk_ids=parameters.get("chunk_ids") or [],
            include_taxonomy=parameters.get("include_taxonomy"),
            taxonomy_mode=parameters.get("taxonomy_mode"),
            taxonomy_generator=parameters.get("taxonomy_generator"),
            taxonomy_processing_mode=parameters.get("taxonomy_processing_mode"),
            taxonomy_anchor_main_topic=parameters.get("taxonomy_anchor_main_topic"),
            taxonomy_chunk_batch_size=parameters.get("taxonomy_chunk_batch_size"),
            collection=parameters.get("collection"),
            model=parameters.get("model"),
            segment_token_size=parameters.get("segment_token_size"),
            segment_overlap_tokens=parameters.get("segment_overlap_tokens"),
            skip_segmentation=parameters.get("skip_segmentation"),
            dry_run=bool(parameters.get("dry_run", False)),
        )

        logger.debug(
            "DEBUG: embedding_executor_start owner_id=%s project_id=%s doc_id=%s doc_ids=%s chunk_ids=%s include_taxonomy=%s taxonomy_mode=%s dry_run=%s",
            owner_id,
            request_payload.project_id,
            request_payload.document_id,
            len(request_payload.document_ids),
            len(request_payload.chunk_ids),
            request_payload.include_taxonomy,
            request_payload.taxonomy_mode,
            request_payload.dry_run,
        )

        if callable(progress_callback):
            progress_callback(5, "Loading chunks for embedding")

        chunks = _load_chunks_for_request(owner_id, request_payload)
        cfg = EmbeddingPluginConfig.load(owner_id)
        include_taxonomy = cfg.include_taxonomy if request_payload.include_taxonomy is None else request_payload.include_taxonomy
        taxonomy_mode_effective = _taxonomy_mode_for_request(owner_id, request_payload)

        resolved_document_ids = sorted(
            {
                str(row.get("document_id") or "")
                for row in chunks
                if str(row.get("document_id") or "")
            }
        )
        logger.debug(
            "DEBUG: embedding_executor_scope_resolved project_id=%s requested_document_id=%s requested_document_ids=%s resolved_document_ids=%s resolved_chunk_count=%s",
            request_payload.project_id,
            request_payload.document_id,
            len(request_payload.document_ids or []),
            resolved_document_ids[:20],
            len(chunks),
        )

        effective_collection = request_payload.collection or cfg.collection
        effective_model = request_payload.model or cfg.ollama_model
        effective_skip_segmentation = cfg.skip_segmentation if request_payload.skip_segmentation is None else bool(request_payload.skip_segmentation)

        logger.debug(
            "DEBUG: embedding_executor_config qdrant_url=%s collection=%s model=%s distance=%s batch_size=%s taxonomy_chunk_batch_size=%s segment_token_size=%s segment_overlap_tokens=%s preprocess_policy=%s include_taxonomy=%s",
            cfg.qdrant_url,
            effective_collection,
            effective_model,
            cfg.distance,
            cfg.batch_size,
            request_payload.taxonomy_chunk_batch_size if request_payload.taxonomy_chunk_batch_size is not None else cfg.taxonomy_chunk_batch_size,
            request_payload.segment_token_size if request_payload.segment_token_size is not None else cfg.segment_token_size,
            request_payload.segment_overlap_tokens if request_payload.segment_overlap_tokens is not None else cfg.segment_overlap_tokens,
            cfg.preprocess_policy,
            include_taxonomy,
        )
        logger.debug(
            "DEBUG: embedding_executor_segmentation skip_segmentation=%s",
            effective_skip_segmentation,
        )
        logger.debug(
            "DEBUG: embedding_executor_chunk_scope total_chunks=%s",
            len(chunks),
        )

        project_record = ProjectRepository(owner_id).get_project_by_id(request_payload.project_id) if request_payload.project_id else None
        document_map: Dict[str, Dict[str, Any]] = {}
        if request_payload.project_id:
            for d in _list_project_documents(owner_id, request_payload.project_id):
                document_map[str(d.get("id"))] = d

        if callable(progress_callback):
            progress_callback(20, "Preparing metadata-rich payloads")

        taxonomy_data = _taxonomy_snapshot(owner_id, request_payload.project_id) if include_taxonomy else {}
        embed_lookup: Dict[str, Dict[str, Any]] = {}
        if include_taxonomy and taxonomy_mode_effective == "chunk":
            annotation_result = _ensure_embed_taxonomy_records(owner_id, request_payload, chunks)
            embed_lookup = _load_embed_taxonomy_lookup(owner_id, chunks)
            missing_chunk_ids = [
                str(c.get("id"))
                for c in chunks
                if c.get("id") and str(c.get("id")) not in embed_lookup
            ]
            logger.debug(
                "DEBUG: embedding_chunk_taxonomy_generation_result mode=chunk requested_chunks=%s embed_lookup_rows=%s missing_embed_rows=%s generated=%s updated_existing=%s skipped=%s failed=%s materialized_taxonomy_id=%s",
                len(chunks),
                len(embed_lookup),
                len(missing_chunk_ids),
                annotation_result.get("generated"),
                annotation_result.get("updated_existing"),
                annotation_result.get("skipped"),
                len(annotation_result.get("failed") or []),
                annotation_result.get("materialized_taxonomy_id"),
            )
            if missing_chunk_ids:
                logger.debug(
                    "DEBUG: embedding_chunk_taxonomy_missing_chunk_ids sample=%s",
                    missing_chunk_ids[:20],
                )
        elif include_taxonomy:
            logger.debug(
                "DEBUG: embedding_taxonomy_mode_non_chunk mode=%s using_taxonomy_snapshot=%s",
                taxonomy_mode_effective,
                bool(taxonomy_data),
            )
        payloads = [
            _build_embedding_payload(
                row,
                project_record,
                document_map,
                include_taxonomy,
                taxonomy_data,
                taxonomy_mode=taxonomy_mode_effective,
                embed_lookup=embed_lookup,
            )
            for row in chunks
        ]
        effective_segment_token_size = _coerce_segment_token_size(
            request_payload.segment_token_size if request_payload.segment_token_size is not None else cfg.segment_token_size,
            cfg.segment_token_size,
        )
        effective_segment_overlap_tokens = _coerce_segment_overlap_tokens(
            request_payload.segment_overlap_tokens if request_payload.segment_overlap_tokens is not None else cfg.segment_overlap_tokens,
            effective_segment_token_size,
            cfg.segment_overlap_tokens,
        )
        segmented_payloads, segment_token_size, segment_overlap_tokens, segmented_parent_count = _expand_payloads_with_micro_segments(
            payloads,
            effective_segment_token_size,
            effective_segment_overlap_tokens,
            skip_segmentation=effective_skip_segmentation,
        )
        taxonomy_attached = any(
            isinstance(p.get("metadata", {}).get("taxonomy"), dict)
            and bool(p.get("metadata", {}).get("taxonomy", {}).get("tree"))
            for p in payloads
        )

        if request_payload.dry_run:
            if callable(progress_callback):
                progress_callback(100, "Dry-run completed")
            logger.debug(
                "DEBUG: embedding_executor_dry_run_completed collection=%s model=%s chunks=%s taxonomy_attached=%s",
                effective_collection,
                effective_model,
                len(chunks),
                taxonomy_attached,
            )
            return {
                "status": "completed",
                "mode": "dry_run",
                "collection": effective_collection,
                "model": effective_model,
                "total_chunks": len(chunks),
                "prepared_segments": len(segmented_payloads),
                "segmented_parent_count": segmented_parent_count,
                "segment_token_size": segment_token_size,
                "segment_overlap_tokens": segment_overlap_tokens,
                "skip_segmentation": effective_skip_segmentation,
                "taxonomy_attached": taxonomy_attached,
                "sample_payload": segmented_payloads[:3],
            }

        qdrant_probe = _probe_qdrant_collections(cfg.qdrant_url)
        logger.debug(
            "DEBUG: qdrant_probe url=%s ok=%s status_code=%s collection_count=%s sample_collections=%s error=%s",
            cfg.qdrant_url,
            qdrant_probe.get("ok"),
            qdrant_probe.get("status_code"),
            qdrant_probe.get("collection_count"),
            (qdrant_probe.get("collections") or [])[:10],
            qdrant_probe.get("error"),
        )

        if not segmented_payloads:
            if callable(progress_callback):
                progress_callback(100, "No payloads generated; nothing to index")
            return {
                "status": "completed",
                "mode": "indexed",
                "collection": effective_collection,
                "model": effective_model,
                "total_chunks": len(chunks),
                "taxonomy_attached": taxonomy_attached,
                "prepared_payloads": len(payloads),
                "prepared_segments": 0,
                "segmented_parent_count": segmented_parent_count,
                "segment_token_size": segment_token_size,
                "segment_overlap_tokens": segment_overlap_tokens,
                "skip_segmentation": effective_skip_segmentation,
                "qdrant_probe": qdrant_probe,
                "upserted_points": 0,
                "collection_created": False,
            }

        if callable(progress_callback):
            progress_callback(45, "Requesting embeddings from Ollama")

        texts = [str(p.get("text") or "").strip() for p in segmented_payloads]
        vectors = _embed_texts_with_ollama(cfg.ollama_url, effective_model, texts)
        if not vectors:
            raise ValueError("Ollama returned no embeddings")

        expected_dim = len(vectors[0])
        if expected_dim <= 0:
            raise ValueError("Invalid embedding dimension returned by Ollama")
        for i, vector in enumerate(vectors):
            if len(vector) != expected_dim:
                raise ValueError(
                    f"Embedding dimension mismatch at index {i}: expected {expected_dim}, got {len(vector)}"
                )

        if callable(progress_callback):
            progress_callback(65, "Ensuring Qdrant collection")

        collection_info = _ensure_qdrant_collection(
            qdrant_url=cfg.qdrant_url,
            collection=effective_collection,
            vector_size=expected_dim,
            distance=cfg.distance,
        )

        batch_size = max(1, int(cfg.batch_size or 128))
        total_points = len(segmented_payloads)
        upserted = 0

        if callable(progress_callback):
            progress_callback(75, "Upserting vectors to Qdrant")

        for start in range(0, total_points, batch_size):
            end = min(start + batch_size, total_points)
            batch_points = [
                _embedding_payload_to_qdrant_point(segmented_payloads[idx], vectors[idx])
                for idx in range(start, end)
            ]
            _upsert_qdrant_points(cfg.qdrant_url, effective_collection, batch_points)
            upserted += len(batch_points)

            if callable(progress_callback):
                phase_progress = 75 + int((upserted / total_points) * 23)
                progress_callback(min(98, phase_progress), f"Upserted {upserted}/{total_points} vectors")

        if callable(progress_callback):
            progress_callback(100, "Embedding + Qdrant indexing completed")

        return {
            "status": "completed",
            "mode": "indexed",
            "collection": effective_collection,
            "model": effective_model,
            "total_chunks": len(chunks),
            "taxonomy_attached": taxonomy_attached,
            "prepared_payloads": len(payloads),
            "prepared_segments": len(segmented_payloads),
            "segmented_parent_count": segmented_parent_count,
            "segment_token_size": segment_token_size,
            "segment_overlap_tokens": segment_overlap_tokens,
            "skip_segmentation": effective_skip_segmentation,
            "qdrant_probe": qdrant_probe,
            "upserted_points": upserted,
            "embedding_dimension": expected_dim,
            "collection_created": bool(collection_info.get("created")),
            "collection_distance": collection_info.get("distance"),
        }

    __call__ = execute


class EmbeddingPageExtension:
    """Streamlit page extension for embedding workflows."""

    key = "embeddings"
    label = "🧠 Embeddings"
    section = "plugin"
    order = 10

    @staticmethod
    def renderer() -> None:
        import streamlit as st
        from src.compileo.features.gui.services.api_client import api_client
        from src.compileo.features.gui.utils.ollama_utils import get_ollama_models

        st.title("🧠 Embeddings")
        st.caption("Qdrant + Ollama embedding workflow (plugin)")

        settings_resp = api_client.get("/api/v1/plugins/embeddings/settings") or {}
        scope_root = api_client.get("/api/v1/plugins/embeddings/scope") or {}
        projects = scope_root.get("projects", [])

        if not projects:
            st.warning("No projects found. Create a project and process documents before embedding.")
            return

        project_labels = [f"{p.get('name', 'Unnamed')} ({p.get('id')})" for p in projects]
        project_lookup = {label: str(projects[i].get("id")) for i, label in enumerate(project_labels)}
        selected_project_label = st.selectbox("Project", options=project_labels, key="embed_project_select")
        selected_project_id = project_lookup[selected_project_label]

        scope = api_client.get(f"/api/v1/plugins/embeddings/scope?project_id={selected_project_id}") or {}
        documents = scope.get("documents", [])
        legacy_taxonomy_status = scope.get("taxonomy", {})

        with st.expander("Connection & Model Settings", expanded=True):
            qdrant_url = st.text_input("Qdrant URL", value=settings_resp.get("qdrant_url", "http://localhost:6333"))
            collection = st.text_input("Collection", value=settings_resp.get("collection", "compileo_chunks"))
            ollama_url = st.text_input("Ollama URL", value=settings_resp.get("ollama_url", "http://localhost:11434"))
            ollama_models = get_ollama_models(ollama_url)
            if not ollama_models:
                ollama_models = scope.get("ollama_models", []) or [settings_resp.get("ollama_model", "nomic-embed-text")]
            default_model = settings_resp.get("ollama_model", ollama_models[0])
            if default_model not in ollama_models:
                ollama_models = [default_model] + ollama_models
            ollama_model = st.selectbox(
                "Ollama Embedding Model",
                options=ollama_models,
                index=ollama_models.index(default_model),
            )
            distance_options = ["Cosine", "Dot", "Euclid"]
            selected_distance = settings_resp.get("distance")
            distance_index = distance_options.index(selected_distance) if selected_distance in distance_options else 0
            distance = st.selectbox("Distance", options=distance_options, index=distance_index)
            batch_size = st.number_input("Batch Size", min_value=1, max_value=4096, value=int(settings_resp.get("batch_size", 128)))
            taxonomy_chunk_batch_size = st.number_input(
                "Taxonomy chunk batch size",
                min_value=1,
                max_value=256,
                value=int(settings_resp.get("taxonomy_chunk_batch_size", 10)),
                help="Chunks processed per taxonomy batch. Output taxonomy remains chunk-specific per chunk record.",
            )
            default_segment_token_size = max(
                256,
                min(
                    1024,
                    _coerce_segment_token_size(settings_resp.get("segment_token_size", 512), 512),
                ),
            )
            segment_token_size = st.slider(
                "Segment token size (embedding micro-segmentation)",
                min_value=256,
                max_value=1024,
                value=int(default_segment_token_size),
                step=32,
                help="Typical QA RAG range: 350–700 tokens. Default 512.",
            )
            default_segment_overlap_tokens = max(
                40,
                min(
                    200,
                    _coerce_segment_overlap_tokens(
                        settings_resp.get("segment_overlap_tokens", 80),
                        int(segment_token_size),
                        80,
                    ),
                ),
            )
            segment_overlap_tokens = st.slider(
                "Segment overlap tokens",
                min_value=40,
                max_value=200,
                value=int(default_segment_overlap_tokens),
                step=8,
                help="Typical QA RAG range: 60–120 tokens. Default 80.",
            )
            skip_segmentation = st.checkbox(
                "Skip micro-segmentation (embed each selected chunk as-is)",
                value=bool(settings_resp.get("skip_segmentation", False)),
                key="embed_skip_segmentation",
                help="Enable this when your input chunks are already sized appropriately for embedding.",
            )
            preprocess_policy = st.text_input("Preprocess policy", value=settings_resp.get("preprocess_policy", "markdown_preserve_headings"))
            taxonomy_anchor_main_topic = st.checkbox(
                "Anchor taxonomy top category to chunk main topic",
                value=bool(settings_resp.get("taxonomy_anchor_main_topic", True)),
                key="embed_taxonomy_anchor_main_topic",
            )

            if st.button("Save Embedding Settings", key="embed_settings_save"):
                save_resp = api_client.post(
                    "/api/v1/plugins/embeddings/settings",
                    data={
                        "qdrant_url": qdrant_url,
                        "collection": collection,
                        "ollama_url": ollama_url,
                        "ollama_model": ollama_model,
                        "distance": distance,
                        "batch_size": int(batch_size),
                        "include_taxonomy": bool(settings_resp.get("include_taxonomy", True)),
                        "taxonomy_mode": settings_resp.get("taxonomy_mode", "chunk"),
                        "preprocess_policy": preprocess_policy,
                        "taxonomy_generator": settings_resp.get("taxonomy_generator", "gemini"),
                        "taxonomy_processing_mode": settings_resp.get("taxonomy_processing_mode", "fast"),
                        "taxonomy_anchor_main_topic": taxonomy_anchor_main_topic,
                        "taxonomy_chunk_batch_size": int(taxonomy_chunk_batch_size),
                        "segment_token_size": int(segment_token_size),
                        "segment_overlap_tokens": int(segment_overlap_tokens),
                        "skip_segmentation": bool(skip_segmentation),
                    },
                )
                if save_resp:
                    st.success("Embedding settings saved")

        st.divider()
        st.subheader("Index Scope")

        if not documents:
            st.warning("No documents found in this project.")
            return

        scope_mode = st.radio(
            "Choose indexing scope",
            options=["All documents in project", "Selected documents only"],
            horizontal=True,
            key="embed_scope_mode",
        )

        doc_label_map = {
            f"{d.get('name', 'Unnamed')} (chunks: {d.get('chunk_count', 0)})": str(d.get("id"))
            for d in documents
        }

        selected_document_ids: List[str] = []
        if scope_mode == "Selected documents only":
            selected_doc_labels = st.multiselect(
                "Documents",
                options=list(doc_label_map.keys()),
                key="embed_documents_multiselect",
            )
            selected_document_ids = [doc_label_map[label] for label in selected_doc_labels]
            if not selected_document_ids:
                st.info("Select at least one document for scoped indexing.")

        include_taxonomy = st.checkbox(
            "Include taxonomy metadata",
            value=bool(settings_resp.get("include_taxonomy", True)),
            key="embed_include_taxonomy",
        )

        taxonomy_mode = st.selectbox(
            "Taxonomy mode",
            options=["chunk", "legacy"],
            index=0 if settings_resp.get("taxonomy_mode", "chunk") == "chunk" else 1,
            key="embed_taxonomy_mode_select",
            help="chunk = embedding-only per-chunk taxonomy cache in embed table; legacy = project taxonomy matching",
        )

        taxonomy_generator = settings_resp.get("taxonomy_generator", "gemini")
        taxonomy_processing_mode = settings_resp.get("taxonomy_processing_mode", "fast")

        if include_taxonomy:
            if taxonomy_mode == "chunk":
                taxonomy_generator = st.selectbox(
                    "Taxonomy AI Generator",
                    options=["gemini", "grok", "openai", "ollama"],
                    index=["gemini", "grok", "openai", "ollama"].index(taxonomy_generator)
                    if taxonomy_generator in {"gemini", "grok", "openai", "ollama"}
                    else 0,
                    key="embed_taxonomy_generator_chunk",
                    help="AI provider for generating per-chunk taxonomy during embedding",
                )
                taxonomy_processing_mode = st.selectbox(
                    "Taxonomy Processing Mode",
                    options=["fast", "complete"],
                    index=0 if taxonomy_processing_mode == "fast" else 1,
                    key="embed_taxonomy_mode_chunk",
                )
                scoped_status: Dict[str, Any] = {}
                if scope_mode == "Selected documents only":
                    if selected_document_ids:
                        selected_doc_csv = ",".join(selected_document_ids)
                        scoped_status = api_client.get(
                            f"/api/v1/plugins/embeddings/scope?project_id={selected_project_id}&document_ids={selected_doc_csv}"
                        ) or {}
                    else:
                        scoped_status = {
                            "chunk_taxonomy": {
                                "scope_document_count": 0,
                                "scope_chunk_count": 0,
                                "chunks_with_embed_taxonomy": 0,
                                "missing_chunks": 0,
                                "fully_generated": False,
                            }
                        }
                else:
                    scoped_status = api_client.get(
                        f"/api/v1/plugins/embeddings/scope?project_id={selected_project_id}"
                    ) or {}

                chunk_taxonomy_status = scoped_status.get("chunk_taxonomy", {})
                scope_chunk_count = int(chunk_taxonomy_status.get("scope_chunk_count") or 0)
                generated_chunks = int(chunk_taxonomy_status.get("chunks_with_embed_taxonomy") or 0)
                missing_chunks = int(chunk_taxonomy_status.get("missing_chunks") or 0)

                if scope_mode == "Selected documents only" and not selected_document_ids:
                    st.info("Select at least one document to evaluate chunk taxonomy coverage for this scope.")
                elif scope_chunk_count <= 0:
                    st.warning("No chunks found in selected scope. Run chunking first.")
                elif missing_chunks == 0:
                    st.success(
                        f"Chunk taxonomy ready for selected scope ({generated_chunks}/{scope_chunk_count} chunks)."
                    )
                elif generated_chunks == 0:
                    st.warning(
                        "No chunk taxonomy exists for selected scope yet. "
                        "It will be generated during embedding indexing."
                    )
                else:
                    st.warning(
                        f"Chunk taxonomy partially ready for selected scope "
                        f"({generated_chunks}/{scope_chunk_count} chunks). "
                        f"Missing {missing_chunks} chunks will be generated during indexing."
                    )
            else:
                if legacy_taxonomy_status.get("exists"):
                    st.success(
                        f"Using existing taxonomy: {legacy_taxonomy_status.get('latest_name')} "
                        f"(total: {legacy_taxonomy_status.get('count', 1)})"
                    )
                else:
                    st.warning("No taxonomy exists for this project. It will be auto-generated before embedding.")
                    taxonomy_generator = st.selectbox(
                        "Taxonomy AI Generator",
                        options=["gemini", "grok", "ollama", "openai"],
                        index=["gemini", "grok", "ollama", "openai"].index(taxonomy_generator)
                        if taxonomy_generator in {"gemini", "grok", "ollama", "openai"}
                        else 0,
                        key="embed_taxonomy_generator",
                    )
                    taxonomy_processing_mode = st.selectbox(
                        "Taxonomy Processing Mode",
                        options=["fast", "complete"],
                        index=0 if taxonomy_processing_mode == "fast" else 1,
                        key="embed_taxonomy_mode",
                    )

        dry_run = st.checkbox("Dry-run (prepare payload only)", value=True, key="embed_dry_run")

        request_body = {
            "project_id": selected_project_id,
            "document_ids": selected_document_ids,
            "include_taxonomy": include_taxonomy,
            "taxonomy_mode": taxonomy_mode,
            "auto_generate_taxonomy": include_taxonomy and taxonomy_mode == "legacy" and not bool(legacy_taxonomy_status.get("exists")),
            "taxonomy_generator": taxonomy_generator,
            "taxonomy_processing_mode": taxonomy_processing_mode,
            "taxonomy_anchor_main_topic": taxonomy_anchor_main_topic,
            "taxonomy_chunk_batch_size": int(taxonomy_chunk_batch_size),
            "segment_token_size": int(segment_token_size),
            "segment_overlap_tokens": int(segment_overlap_tokens),
            "skip_segmentation": bool(skip_segmentation),
            "model": ollama_model,
            "collection": collection,
            "dry_run": dry_run,
        }

        col1, col2 = st.columns(2)
        with col1:
            if st.button("Preview Payload", key="embed_preview"):
                preview = api_client.post("/api/v1/plugins/embeddings/index/preview", data=request_body)
                if preview:
                    st.json(preview)

        with col2:
            if st.button("Submit Index Job", key="embed_submit", type="primary"):
                if scope_mode == "Selected documents only" and not selected_document_ids:
                    st.error("Select at least one document or switch scope to all documents.")
                else:
                    result = api_client.post("/api/v1/plugins/embeddings/index", data=request_body)
                    if result and result.get("job_id"):
                        st.success(f"Embedding job submitted: {result['job_id']}")
                        if result.get("taxonomy_status", {}).get("generated"):
                            st.info("Taxonomy was auto-generated for this project before job submission.")

        st.info(
            "Metadata is built automatically from project/document/chunk records and existing chunk metadata, "
            "with semantic tags inferred for RAG-friendly payload filtering."
        )


@click.group("embeddings")
def embeddings_cli():
    """Embedding plugin commands."""
    pass


@embeddings_cli.command("settings")
@click.option("--owner-id", required=True)
@click.option("--qdrant-url", default=None)
@click.option("--collection", default=None)
@click.option("--ollama-url", default=None)
@click.option("--ollama-model", default=None)
@click.option("--distance", default=None)
@click.option("--batch-size", type=int, default=None)
@click.option("--include-taxonomy/--no-include-taxonomy", default=None)
@click.option("--taxonomy-mode", default=None)
@click.option("--taxonomy-generator", default=None)
@click.option("--taxonomy-processing-mode", default=None)
@click.option("--taxonomy-anchor-main-topic/--no-taxonomy-anchor-main-topic", default=None)
@click.option("--taxonomy-chunk-batch-size", type=int, default=None)
@click.option("--segment-token-size", type=int, default=None)
@click.option("--segment-overlap-tokens", type=int, default=None)
@click.option("--skip-segmentation/--no-skip-segmentation", default=None)
@click.option("--preprocess-policy", default=None)
def cli_settings(
    owner_id: str,
    qdrant_url: Optional[str],
    collection: Optional[str],
    ollama_url: Optional[str],
    ollama_model: Optional[str],
    distance: Optional[str],
    batch_size: Optional[int],
    include_taxonomy: Optional[bool],
    taxonomy_mode: Optional[str],
    taxonomy_generator: Optional[str],
    taxonomy_processing_mode: Optional[str],
    taxonomy_anchor_main_topic: Optional[bool],
    taxonomy_chunk_batch_size: Optional[int],
    segment_token_size: Optional[int],
    segment_overlap_tokens: Optional[int],
    skip_segmentation: Optional[bool],
    preprocess_policy: Optional[str],
):
    """Read/update embedding settings for a user."""
    cfg = EmbeddingPluginConfig.load(owner_id)
    if qdrant_url is not None:
        cfg.qdrant_url = qdrant_url
    if collection is not None:
        cfg.collection = collection
    if ollama_url is not None:
        cfg.ollama_url = ollama_url
    if ollama_model is not None:
        cfg.ollama_model = ollama_model
    if distance is not None:
        cfg.distance = distance
    if batch_size is not None:
        cfg.batch_size = max(1, batch_size)
    if include_taxonomy is not None:
        cfg.include_taxonomy = include_taxonomy
    if taxonomy_mode is not None:
        cfg.taxonomy_mode = taxonomy_mode
    if taxonomy_generator is not None:
        cfg.taxonomy_generator = taxonomy_generator
    if taxonomy_processing_mode is not None:
        cfg.taxonomy_processing_mode = taxonomy_processing_mode
    if taxonomy_anchor_main_topic is not None:
        cfg.taxonomy_anchor_main_topic = taxonomy_anchor_main_topic
    if taxonomy_chunk_batch_size is not None:
        cfg.taxonomy_chunk_batch_size = _coerce_taxonomy_chunk_batch_size(
            taxonomy_chunk_batch_size,
            cfg.taxonomy_chunk_batch_size,
        )
    if segment_token_size is not None:
        cfg.segment_token_size = _coerce_segment_token_size(segment_token_size, cfg.segment_token_size)
    if segment_overlap_tokens is not None:
        cfg.segment_overlap_tokens = _coerce_segment_overlap_tokens(
            segment_overlap_tokens,
            cfg.segment_token_size,
            cfg.segment_overlap_tokens,
        )
    elif segment_token_size is not None:
        cfg.segment_overlap_tokens = _coerce_segment_overlap_tokens(
            cfg.segment_overlap_tokens,
            cfg.segment_token_size,
            _default_segment_overlap_tokens(cfg.segment_token_size),
        )
    if skip_segmentation is not None:
        cfg.skip_segmentation = bool(skip_segmentation)
    if preprocess_policy is not None:
        cfg.preprocess_policy = preprocess_policy

    cfg.save(owner_id)
    click.echo(json.dumps(cfg.__dict__, indent=2))


@embeddings_cli.command("index")
@click.option("--owner-id", required=True)
@click.option("--project-id", required=True)
@click.option("--document-id", "document_ids", multiple=True)
@click.option("--taxonomy-anchor-main-topic/--no-taxonomy-anchor-main-topic", default=None)
@click.option("--taxonomy-chunk-batch-size", type=int, default=None)
@click.option("--segment-token-size", type=int, default=None)
@click.option("--segment-overlap-tokens", type=int, default=None)
@click.option("--skip-segmentation/--no-skip-segmentation", default=None)
@click.option("--dry-run", is_flag=True, default=False)
def cli_index(
    owner_id: str,
    project_id: str,
    document_ids: List[str],
    taxonomy_anchor_main_topic: Optional[bool],
    taxonomy_chunk_batch_size: Optional[int],
    segment_token_size: Optional[int],
    segment_overlap_tokens: Optional[int],
    skip_segmentation: Optional[bool],
    dry_run: bool,
):
    """Run embedding executor directly (CLI helper)."""
    executor = QdrantEmbeddingJobExecutor()
    cfg = EmbeddingPluginConfig.load(owner_id)
    effective_segment_token_size = (
        _coerce_segment_token_size(segment_token_size, cfg.segment_token_size)
        if segment_token_size is not None
        else cfg.segment_token_size
    )
    effective_segment_overlap_tokens = (
        _coerce_segment_overlap_tokens(segment_overlap_tokens, effective_segment_token_size, cfg.segment_overlap_tokens)
        if segment_overlap_tokens is not None
        else _coerce_segment_overlap_tokens(cfg.segment_overlap_tokens, effective_segment_token_size, cfg.segment_overlap_tokens)
    )
    result = executor.execute(
        {
            "owner_id": owner_id,
            "project_id": project_id,
            "document_ids": list(document_ids),
            "include_taxonomy": True,
            "taxonomy_mode": "chunk",
            "taxonomy_anchor_main_topic": taxonomy_anchor_main_topic,
            "taxonomy_chunk_batch_size": taxonomy_chunk_batch_size,
            "segment_token_size": effective_segment_token_size,
            "segment_overlap_tokens": effective_segment_overlap_tokens,
            "skip_segmentation": skip_segmentation,
            "dry_run": dry_run,
        },
        progress_callback=lambda p, m="": click.echo(f"[{int(float(p))}%] {m}"),
    )
    click.echo(json.dumps(result, indent=2, default=str))
