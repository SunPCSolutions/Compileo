from .embedding_plugin import (
    plugin_router,
    embeddings_cli,
    EmbeddingPageExtension,
    QdrantEmbeddingJobExecutor,
)

